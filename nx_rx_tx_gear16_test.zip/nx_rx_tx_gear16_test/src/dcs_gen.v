`timescale 1ns/100ps
//`define SIM

module dcs_gen (
		input  wire        clk           ,      //about 11.375MHz
		input  wire        rstn          , 
		output reg         txclk_hsen    ,   
	  output reg         hsxx_clk_en   ,   
	  output reg         txclk_lp_p    ,   
	  output reg         txclk_lp_n    ,  
		output reg         dcs_init_done ,
		output reg         lp            ,
		output reg         ln            
	);

	localparam  DCS_LP          = 4'd0; 
	localparam  DCS_EME         = 4'd1; 
	localparam  DCS_LPDT_CM     = 4'd2; 
	localparam  DCS_DI          = 4'd3; 
	localparam  DCS_D0_WC0      = 4'd4;  
	localparam  DCS_D1_WC1      = 4'd5;         
	localparam  DCS_ECC         = 4'd6; 
	localparam  DCS_LP_DATA     = 4'd7; 
	localparam  DCS_CRC         = 4'd8;   
	localparam  DCS_MARK_1      = 4'd9;  
	localparam  DCS_IDLE        = 4'd10;  
	localparam  DCS_DONE_WAIT   = 4'd11;  
	localparam  DCS_FINISH      = 4'd12;     

	reg  [3:0]  dcs_sm;  
	reg         wait_20ms_done; 
	reg         wait_10ms_done; 
	reg         wait_5ms_done;
	reg         wait_120ms_done;

	reg  [4:0]  dcs_bit_cnt; 
	reg  [15:0] dcs_byte_cnt; 
	reg         dcs_eme_t1;
	reg         dcs_eme_end;
	reg         dcs_byte_end; 
	reg  [5:0]  dcs_byte_num_dec1; 
	reg  [5:0]  dcs_byte_num;  
	reg         dcs_pkg_end; 
	reg         dcs_crc_end;
	reg         dcs_sp_pram; 
	reg  [7:0]  dcs_sp_cmd;  
	reg  [7:0]  dcs_sp_data;  
	reg         dcs_sp;
	reg         dcs_end; 
	reg         dcs_intvl_wait_end; 

	reg         rom_rd;  
	reg  [10:0] rom_addr;
	wire [8:0]  rom_out;
	reg  [7:0]  dcs_data;

	reg  [23:0] ecc_din;
	wire [7:0]  ecc_out;      

	wire        crc_init;
	reg  [7:0]  crc_din; 
	reg         din_en;  
	wire [15:0] crc_out;
	
	reg  [2:0]  state_cnt;     

//DCS state machine
	always @(posedge clk or negedge rstn) begin
		if(!rstn) begin
			dcs_sm <= DCS_LP;       
		end  
		else begin
			case (dcs_sm)   
				DCS_LP : begin    
					if (dcs_byte_end & wait_20ms_done) 
						dcs_sm <= DCS_EME;
					end
				DCS_EME : begin 
					if (dcs_eme_end) 
						dcs_sm <= DCS_LPDT_CM;
				end
				DCS_LPDT_CM : begin 
					if (dcs_byte_end) 
						dcs_sm <= DCS_DI;
				end
				DCS_DI : begin 
					if (dcs_byte_end) 
						dcs_sm <= DCS_D0_WC0;
				end 
				DCS_D0_WC0 : begin
					if (dcs_byte_end) 
						dcs_sm <= DCS_D1_WC1;
				end
				DCS_D1_WC1 : begin 
					if (dcs_byte_end) 
						dcs_sm <= DCS_ECC;
				end
				DCS_ECC : begin
					if (dcs_byte_end) begin
						if (dcs_sp) 
							dcs_sm <= DCS_MARK_1; 
						else
							dcs_sm <= DCS_LP_DATA;
					end
				end
				DCS_LP_DATA : begin  
					if (dcs_byte_end & dcs_pkg_end) 
						dcs_sm <= DCS_CRC;
				end
				DCS_CRC : begin
					if (dcs_byte_end & dcs_crc_end) 
						dcs_sm <= DCS_MARK_1;       
				end
				DCS_MARK_1 : begin
					if (dcs_end) 
						dcs_sm <= DCS_DONE_WAIT;
					else
						dcs_sm <= DCS_IDLE;
				end
				DCS_IDLE : begin  
					if ({dcs_sp,dcs_sp_pram} == 2'b10 && dcs_sp_cmd == 8'h11) begin // short command (sleep out 8'h11) with no parameter
						if (dcs_byte_end & wait_120ms_done)
							dcs_sm <= DCS_EME;
					end
					else if (dcs_byte_end & dcs_intvl_wait_end)
						dcs_sm <= DCS_EME;
				end 
				DCS_DONE_WAIT : begin 
					if (dcs_byte_end & wait_10ms_done)   
						dcs_sm <= DCS_FINISH;              
				end
				DCS_FINISH : ; 
			endcase
		end
	end

	//	generate reset signal to the display
	/*after entering DCS_LP, the data line changes to LP11, after waiting 54x8x24/10.44=1ms, the resx is asserted, it keeps for 8x24/10.44=18.39us*/   
/*
	always @(posedge clk or negedge rstn) begin
		if (~rstn) 
			resx <= 1; 
		else 
			resx <= ~(dcs_sm == DCS_LP && dcs_byte_cnt[15:3] == 13'd54);
	end
*/ 
	/*after entering DCS_LP, the data line changes to LP11, after waiting 2ms, the resx is asserted, it keeps for 16x24/10.44=36.78us*/    

	 // counter value for wait time   
	 always @(posedge clk or negedge rstn) begin
      if (~rstn) begin
         wait_20ms_done <= 0; 
      	 wait_10ms_done <= 0; 
      	 wait_5ms_done <= 0;
      	 wait_120ms_done <= 0;
      	 dcs_intvl_wait_end <= 0;
      end
      else begin
         wait_20ms_done <= (dcs_byte_cnt == 10000);   //50ms:16'd10000 //change!
      	 wait_10ms_done <= (dcs_byte_cnt == 5000);   //20ms:16'd10000 //change!
      	 wait_5ms_done <= (dcs_byte_cnt == 2500);   //50ms:16'd25000
      	 wait_120ms_done <= (dcs_byte_cnt == 60000); //120ms: 16'd60000                
      	 dcs_intvl_wait_end <= (dcs_byte_cnt == 20);
      end
	 end

	// bit/byte counter genertion and the end indicator generated at proper counter value      
	always @(posedge clk or negedge rstn) begin
		if(!rstn) begin 
			dcs_bit_cnt  <= 0; 
			dcs_byte_cnt <= 0;  
			dcs_eme_t1   <= 0;  
			dcs_eme_end  <= 0;  
			dcs_byte_end <= 0; 
			dcs_byte_num <= 0;
			dcs_pkg_end  <= 0; 
			dcs_crc_end  <= 0;   
		end
		else begin 
			if ((dcs_sm == DCS_EME && dcs_eme_end == 1) || dcs_byte_end == 1)
				dcs_bit_cnt <= 0;          
			else if (dcs_sm != DCS_MARK_1 && dcs_sm != DCS_FINISH)              
				dcs_bit_cnt <= dcs_bit_cnt + 1;
			if (dcs_pkg_end)
				dcs_byte_cnt <= 0; 
			else if (dcs_sm == DCS_LP || dcs_sm == DCS_LP_DATA || dcs_sm == DCS_CRC || dcs_sm == DCS_IDLE || dcs_sm == DCS_DONE_WAIT) begin     
				if (dcs_byte_end == 1)
					dcs_byte_cnt <= dcs_byte_cnt + 1;
			end
			else
				dcs_byte_cnt <= 0;             

			dcs_eme_t1 <= (dcs_sm == DCS_EME && dcs_bit_cnt == 5'd1);    
			dcs_eme_end <= (dcs_sm == DCS_EME && dcs_bit_cnt == 5'd2);
			dcs_byte_end <= ((dcs_sm == DCS_LPDT_CM || (dcs_sm == DCS_CRC && dcs_crc_end == 1'b1) || (dcs_sm == DCS_ECC && dcs_sp == 1'b1)) && dcs_bit_cnt == 5'd14) || (dcs_sm != DCS_LPDT_CM && dcs_bit_cnt == 5'd22); 
			dcs_byte_num <= dcs_byte_num_dec1 + 1;                                                                        
			dcs_pkg_end <= (dcs_bit_cnt == 5'd22) && (dcs_sm == DCS_LP_DATA) && (dcs_byte_cnt[5:0] == dcs_byte_num_dec1); 
			dcs_crc_end <= dcs_byte_cnt[0] == 1'd1;                                                                       
		end
	end

	// counter value for wait time   
   always @(posedge clk or negedge rstn) begin
      if (~rstn) begin
         dcs_sp       <= 0;  
         dcs_sp_pram  <= 0;  
         dcs_sp_cmd   <= 0; 
         dcs_sp_data  <= 0;  
         dcs_end      <= 0;
         dcs_byte_num_dec1 <= 0;
      end
      else begin
         if (dcs_sm == DCS_LPDT_CM) begin
            dcs_sp  <= ~rom_out[7];
            dcs_end <= rom_out[8];
            dcs_sp_pram <= rom_out[6];    
            dcs_byte_num_dec1 <= rom_out[5:0];  
         end
         if (dcs_sm == DCS_DI && dcs_byte_end)  
	          dcs_sp_cmd <= rom_out[7:0]; 
	       if (dcs_sm == DCS_D0_WC0 && dcs_byte_end)      
	          dcs_sp_data <= rom_out[7:0];                                
      end
   end



	// DCS command read out from the ROM and shifted out
	always @(posedge clk or negedge rstn) begin
		if(!rstn) begin
			rom_rd   <= 0;
			rom_addr <= 0; 
			dcs_data <= 0;  
			dcs_init_done <= 0;
		end
		else begin  
			rom_rd <= (dcs_eme_t1 | ((dcs_bit_cnt == 5'd13) & ((dcs_sp & ((dcs_sm == DCS_DI) | (dcs_sp_pram & (dcs_sm == DCS_D0_WC0)))) | 
					(~dcs_sp & (dcs_sm == DCS_ECC)) | ((dcs_sm == DCS_LP_DATA) & (dcs_byte_cnt[5:0] != dcs_byte_num_dec1)))));
			if (rom_rd)
				rom_addr <= /*(rom_addr == 45) ? 0 : */(rom_addr + 1);
			if (dcs_byte_end | dcs_eme_end) begin
				case (dcs_sm)
					DCS_EME : begin
						dcs_data <= 8'h87;
					end 
					DCS_LPDT_CM : begin 
						casex ({dcs_sp,dcs_sp_pram})
							2'b10   : dcs_data <= 8'h05;  //data type of the short packet, DCS write, no parameters      
							2'b11   : dcs_data <= 8'h15;  //data type of the short packet, DCS write, 1 parameter 
//							2'b01   : dcs_data <= 8'h29;        
							default : dcs_data <= 8'h39;  //data type of the long packet, DCS Long Write/Write_LUT Command Packet          
						endcase
					end
					DCS_DI : begin
						if (dcs_sp) begin
               dcs_data <= rom_out[7:0];          //short packet, the first byte of DCS write with/without parameters
						end
						else begin
							 dcs_data <= {2'h0, dcs_byte_num};  //long packet, lower byte of the word count is read from the rom, only supports no more than 64 bytes  
						end
					end
					DCS_D0_WC0 : begin
						if (dcs_sp & dcs_sp_pram) begin  
							 dcs_data <= rom_out[7:0];          //short packet, the second byte of DCS write with/without parameters is read from the rom 
						end
						else
							 dcs_data <= 8'h0;                  //long packet, higher byte of the word count, set to 0; or short packet, DCS write without parameters, the second byte is set to 0      
					end
					DCS_D1_WC1 : begin
						dcs_data <= ecc_out;
					end 
					DCS_LP_DATA : begin
						if (dcs_pkg_end)
							 dcs_data <= crc_out[7:0]; 
						else 
							 dcs_data <= rom_out[7:0];   
					end
					DCS_CRC : begin
						dcs_data <= crc_out[15:8];
					end
					
					default : begin
             dcs_data <= rom_out[7:0];
					end
				endcase
			end
			else if (dcs_bit_cnt[0])
				dcs_data <= {1'b0,dcs_data[7:1]};
				
			if (dcs_sm == DCS_FINISH && state_cnt == 7)
			  dcs_init_done <= 1'b1;
		end
  end
	
	 lrom_2048x9 lrom_2048x9 (
	    .clk_i                 (clk          ),      
      .dps_i                 (1'b0         ),      
      .rst_i                 (~rstn        ), 
      .clk_en_i              (rom_rd       ),      
      .addr_i                (rom_addr     ),      
      .rd_data_o             (rom_out      ),      
      .lramready_o           (             ),      
      .rd_datavalid_o        (             )      
   );
	  
//	 pmi_rom #(
//      .pmi_addr_depth       (2048         ),
//      .pmi_addr_width       (11           ),
//      .pmi_data_width       (9            ),
//      .pmi_regmode          ("noreg"      ),
//      .pmi_gsr              ("disable"    ),
//      .pmi_resetmode        ("sync"       ),
//      .pmi_optimization     ("speed"      ),
//      .pmi_init_file        ("dcs_init_bist_new.mem"  ),
//      .pmi_init_file_format ("hex"        ),
//      .pmi_family           ("LIFMDF"     ),
//      .module_type          ("pmi_rom"    ))
//   rom_1024_9 (
//      .Address              (rom_addr     ),
//      .OutClock             (clk          ),
//      .OutClockEn           (rom_rd       ),
//      .Reset                (~rstn        ),
//      .Q                    (rom_out      )
//   );             
	
	ecc_gen ecc_gen_inst (
				.clk          (clk     ),
				.rstn         (rstn    ),
				.din          (ecc_din ),
				.ecc_out      (ecc_out ) 
	); 
	
	crc16_8b crc16_8b_lp (
				.clk          (clk     ),
				.rstn         (rstn    ),
				.init         (crc_init),
				.din          (crc_din ),
				.din_en       (din_en  ),
				.crc          (crc_out )
	);

// generate the ECC and CRC input data 
	assign crc_init = dcs_eme_end;
	always @(posedge clk or negedge rstn) begin
		if(!rstn) begin
			ecc_din  <= 0;
			crc_din  <= 0; 
			din_en   <= 0; 
		end
		else begin  
			if (dcs_bit_cnt == 5'd0) begin               
				if (dcs_sm == DCS_D1_WC1)                 
					ecc_din[23:16] <= dcs_data;            
				if (dcs_sm == DCS_D0_WC0)                 
					ecc_din[15:8] <= dcs_data;             
				if (dcs_sm == DCS_DI)                     
					ecc_din[7:0] <= dcs_data;              
			end 
			if (dcs_sm == DCS_LP_DATA && dcs_bit_cnt == 5'd0) begin
				crc_din <= dcs_data;
				din_en  <= 1;
			end
			else
				din_en <= 0;                                                  
		end
	end
	
//	DCS command serial out
//	DCS_EME(Escape Mode Entry)                      : {lp,ln} = 10->00->01->00 
//	DCS_LPDT_CM(Low-Power Data Transmission Command): {lp,ln} = 10->00->10-00->>10->00->01->00->01->00->01->00->01->00->10-00 (8'h87)
//	DCS_DI(Data Identification)---- 
//		DCS WRITE, no parameters : {lp,ln} = 10->00->01-00->>10->00->01->00->01->00->01->00->01->00->01-00 (8'h05)     
//		DCS WRITE, 1  parameter  : {lp,ln} = 10->00->01-00->>10->00->01->00->10->00->01->00->01->00->01-00 (8'h15)     
//		DCS Long Write/Write_LUT Command Packet  : {lp,ln} = 10->00->01-00->>01->00->10->00->10->00->10->00->01->00->01-00 (8'h39)                 
	always @(posedge clk or negedge rstn) begin
		if(!rstn) begin
			lp <= 1'b1;
			ln <= 1'b1; 
			state_cnt <= 0;
      txclk_hsen <= 0;   
      hsxx_clk_en <= 0;  
      txclk_lp_p <= 1;  
      txclk_lp_n <= 1;
		end
		else begin  

			case (dcs_sm)
				DCS_MARK_1 : begin
					lp <= 1'b1;
					ln <= 1'b0; 
				end
				DCS_EME : begin
					lp <= dcs_bit_cnt == 5'h0;
					ln <= dcs_bit_cnt == 5'h2;
				end
				DCS_LP, DCS_IDLE, DCS_DONE_WAIT, DCS_FINISH : begin
					lp <= 1'b1;  
					ln <= 1'b1;  
				end
				default : begin
					lp <= dcs_data[0] & ~dcs_bit_cnt[0] & ~dcs_bit_cnt[4];    
					ln <= ~dcs_data[0] & ~dcs_bit_cnt[0] & ~dcs_bit_cnt[4];    
				end
			endcase
			
//			if (dcs_sm == DCS_LP) begin
//			   if (dcs_byte_cnt == 256 && dcs_byte_end)
//			      state_cnt <= 1;
//			   else if (state_cnt != 0 && state_cnt != 7)
//			      state_cnt <= state_cnt + 1;
//			end
			if (dcs_sm == DCS_FINISH) begin 
			   if (state_cnt != 7)
            state_cnt <= state_cnt + 1;
      end
      if (state_cnt == 0) begin
         txclk_hsen <= 0;      
         hsxx_clk_en <= 0;    
         txclk_lp_p <= 1;      
         txclk_lp_n <= 1;      
      end
      else if (state_cnt == 1) begin
         txclk_lp_p <= 0;   
         txclk_lp_n <= 1;   
      end
      else if (state_cnt == 2) begin
         txclk_lp_p <= 0;   
         txclk_lp_n <= 0;   
      end
      else if (state_cnt == 3) 
         txclk_hsen <= 1;   
      else if (state_cnt == 4) 
         hsxx_clk_en <= 1; 
		end
	end

// for test
   reg [7:0] dcs_data_tx;
   always @(posedge clk or negedge rstn) begin
      if(!rstn) begin
			   dcs_data_tx <= 0;
		  end
      else begin  
			   if (dcs_bit_cnt == 5'd0 && dcs_sm >= DCS_LPDT_CM && dcs_sm <= DCS_CRC) begin               
				    dcs_data_tx <= dcs_data;                                               
		     end
		  end
	 end
   


endmodule
