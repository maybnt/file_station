// --------------------------------------------------------------------
// >>>>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
// --------------------------------------------------------------------
// Copyright (init_val) 2013 by Lattice Semiconductor Corporation
// --------------------------------------------------------------------
//
// Permission:
//
//   Lattice Semiconductor grants permission to use this code for use
//   in synthesis for any Lattice programmable logic product.  Other
//   use of this code, including the selling or duplication of any
//   portion is strictly prohibited.
//
// Disclaimer:
//
//   This VHDL or Verilog source code is intended as a design reference
//   which illustrates how these types of functions can be implemented.
//   It is the user's responsibility to verify their design for
//   consistency and functionality through the use of formal
//   verification methods.  Lattice Semiconductor provides no warranty
//   regarding the use or functionality of this code.
//
// --------------------------------------------------------------------
//           
//                     Lattice Semiconductor Corporation
//                     5555 NE Moore Court
//                     Hillsboro, OR 97214
//                     U.S.A
//
//                     TEL: 1-800-Lattice (USA and Canada)
//                          408-826-6000 (other locations)
//
//                     web: http://www.latticesemi.com/
//                     email: techsupport@latticesemi.com
//
// --------------------------------------------------------------------
//
// MIPI DPHY TX Design
// 
`timescale 1ns/100ps 

module crc16_32b_one_cycle (
   input  wire        clk,
   input  wire        rstn,
   input  wire [15:0] init_val,
   input  wire [31:0] din,
   input  wire        din_en,
   output wire [15:0] crc
);

   wire [31:0] din_tmp;
   wire [15:0] init_val_tmp;
   wire [15:0] next_crc;
   reg  [15:0] crc_reg;
   
   assign din_tmp = {din[0],din[1],din[2],din[3],din[4],din[5],din[6],din[7],
                     din[8],din[9],din[10],din[11],din[12],din[13],din[14],din[15],
                     din[16],din[17],din[18],din[19],din[20],din[21],din[22],din[23],      
                     din[24],din[25],din[26],din[27],din[28],din[29],din[30],din[31]};
   
   assign init_val_tmp = {init_val[0],init_val[1],init_val[2],init_val[3],init_val[4],init_val[5],init_val[6],init_val[7],
                 init_val[8],init_val[9],init_val[10],init_val[11],init_val[12],init_val[13],init_val[14],init_val[15]};
   
   assign crc = {crc_reg[0],crc_reg[1],crc_reg[2],crc_reg[3],crc_reg[4],crc_reg[5],crc_reg[6],crc_reg[7],
                 crc_reg[8],crc_reg[9],crc_reg[10],crc_reg[11],crc_reg[12],crc_reg[13],crc_reg[14],crc_reg[15]};
   
   always @ (posedge clk or negedge rstn) begin
      if (!rstn) 
         crc_reg <= 16'hffff;                                                                                              
      else if (din_en)
         crc_reg <= next_crc;
   end

   assign next_crc[0] = din_tmp[28] ^ din_tmp[27] ^ din_tmp[26] ^ din_tmp[22] ^ din_tmp[20] ^ din_tmp[19] ^ din_tmp[12] ^ din_tmp[11] ^ din_tmp[8] ^ din_tmp[4] ^ din_tmp[0] ^ init_val_tmp[3] ^ init_val_tmp[4] ^ init_val_tmp[6] ^ init_val_tmp[10] ^ init_val_tmp[11] ^ init_val_tmp[12];
   assign next_crc[1] = din_tmp[29] ^ din_tmp[28] ^ din_tmp[27] ^ din_tmp[23] ^ din_tmp[21] ^ din_tmp[20] ^ din_tmp[13] ^ din_tmp[12] ^ din_tmp[9] ^ din_tmp[5] ^ din_tmp[1] ^ init_val_tmp[4] ^ init_val_tmp[5] ^ init_val_tmp[7] ^ init_val_tmp[11] ^ init_val_tmp[12] ^ init_val_tmp[13];
   assign next_crc[2] = din_tmp[30] ^ din_tmp[29] ^ din_tmp[28] ^ din_tmp[24] ^ din_tmp[22] ^ din_tmp[21] ^ din_tmp[14] ^ din_tmp[13] ^ din_tmp[10] ^ din_tmp[6] ^ din_tmp[2] ^ init_val_tmp[5] ^ init_val_tmp[6] ^ init_val_tmp[8] ^ init_val_tmp[12] ^ init_val_tmp[13] ^ init_val_tmp[14];
   assign next_crc[3] = din_tmp[31] ^ din_tmp[30] ^ din_tmp[29] ^ din_tmp[25] ^ din_tmp[23] ^ din_tmp[22] ^ din_tmp[15] ^ din_tmp[14] ^ din_tmp[11] ^ din_tmp[7] ^ din_tmp[3] ^ init_val_tmp[6] ^ init_val_tmp[7] ^ init_val_tmp[9] ^ init_val_tmp[13] ^ init_val_tmp[14] ^ init_val_tmp[15];
   assign next_crc[4] = din_tmp[31] ^ din_tmp[30] ^ din_tmp[26] ^ din_tmp[24] ^ din_tmp[23] ^ din_tmp[16] ^ din_tmp[15] ^ din_tmp[12] ^ din_tmp[8] ^ din_tmp[4] ^ init_val_tmp[0] ^ init_val_tmp[7] ^ init_val_tmp[8] ^ init_val_tmp[10] ^ init_val_tmp[14] ^ init_val_tmp[15];
   assign next_crc[5] = din_tmp[31] ^ din_tmp[28] ^ din_tmp[26] ^ din_tmp[25] ^ din_tmp[24] ^ din_tmp[22] ^ din_tmp[20] ^ din_tmp[19] ^ din_tmp[17] ^ din_tmp[16] ^ din_tmp[13] ^ din_tmp[12] ^ din_tmp[11] ^ din_tmp[9] ^ din_tmp[8] ^ din_tmp[5] ^ din_tmp[4] ^ din_tmp[0] ^ init_val_tmp[0] ^ init_val_tmp[1] ^ init_val_tmp[3] ^ init_val_tmp[4] ^ init_val_tmp[6] ^ init_val_tmp[8] ^ init_val_tmp[9] ^ init_val_tmp[10] ^ init_val_tmp[12] ^ init_val_tmp[15];
   assign next_crc[6] = din_tmp[29] ^ din_tmp[27] ^ din_tmp[26] ^ din_tmp[25] ^ din_tmp[23] ^ din_tmp[21] ^ din_tmp[20] ^ din_tmp[18] ^ din_tmp[17] ^ din_tmp[14] ^ din_tmp[13] ^ din_tmp[12] ^ din_tmp[10] ^ din_tmp[9] ^ din_tmp[6] ^ din_tmp[5] ^ din_tmp[1] ^ init_val_tmp[1] ^ init_val_tmp[2] ^ init_val_tmp[4] ^ init_val_tmp[5] ^ init_val_tmp[7] ^ init_val_tmp[9] ^ init_val_tmp[10] ^ init_val_tmp[11] ^ init_val_tmp[13];
   assign next_crc[7] = din_tmp[30] ^ din_tmp[28] ^ din_tmp[27] ^ din_tmp[26] ^ din_tmp[24] ^ din_tmp[22] ^ din_tmp[21] ^ din_tmp[19] ^ din_tmp[18] ^ din_tmp[15] ^ din_tmp[14] ^ din_tmp[13] ^ din_tmp[11] ^ din_tmp[10] ^ din_tmp[7] ^ din_tmp[6] ^ din_tmp[2] ^ init_val_tmp[2] ^ init_val_tmp[3] ^ init_val_tmp[5] ^ init_val_tmp[6] ^ init_val_tmp[8] ^ init_val_tmp[10] ^ init_val_tmp[11] ^ init_val_tmp[12] ^ init_val_tmp[14];
   assign next_crc[8] = din_tmp[31] ^ din_tmp[29] ^ din_tmp[28] ^ din_tmp[27] ^ din_tmp[25] ^ din_tmp[23] ^ din_tmp[22] ^ din_tmp[20] ^ din_tmp[19] ^ din_tmp[16] ^ din_tmp[15] ^ din_tmp[14] ^ din_tmp[12] ^ din_tmp[11] ^ din_tmp[8] ^ din_tmp[7] ^ din_tmp[3] ^ init_val_tmp[0] ^ init_val_tmp[3] ^ init_val_tmp[4] ^ init_val_tmp[6] ^ init_val_tmp[7] ^ init_val_tmp[9] ^ init_val_tmp[11] ^ init_val_tmp[12] ^ init_val_tmp[13] ^ init_val_tmp[15];
   assign next_crc[9] = din_tmp[30] ^ din_tmp[29] ^ din_tmp[28] ^ din_tmp[26] ^ din_tmp[24] ^ din_tmp[23] ^ din_tmp[21] ^ din_tmp[20] ^ din_tmp[17] ^ din_tmp[16] ^ din_tmp[15] ^ din_tmp[13] ^ din_tmp[12] ^ din_tmp[9] ^ din_tmp[8] ^ din_tmp[4] ^ init_val_tmp[0] ^ init_val_tmp[1] ^ init_val_tmp[4] ^ init_val_tmp[5] ^ init_val_tmp[7] ^ init_val_tmp[8] ^ init_val_tmp[10] ^ init_val_tmp[12] ^ init_val_tmp[13] ^ init_val_tmp[14];
   assign next_crc[10] = din_tmp[31] ^ din_tmp[30] ^ din_tmp[29] ^ din_tmp[27] ^ din_tmp[25] ^ din_tmp[24] ^ din_tmp[22] ^ din_tmp[21] ^ din_tmp[18] ^ din_tmp[17] ^ din_tmp[16] ^ din_tmp[14] ^ din_tmp[13] ^ din_tmp[10] ^ din_tmp[9] ^ din_tmp[5] ^ init_val_tmp[0] ^ init_val_tmp[1] ^ init_val_tmp[2] ^ init_val_tmp[5] ^ init_val_tmp[6] ^ init_val_tmp[8] ^ init_val_tmp[9] ^ init_val_tmp[11] ^ init_val_tmp[13] ^ init_val_tmp[14] ^ init_val_tmp[15];
   assign next_crc[11] = din_tmp[31] ^ din_tmp[30] ^ din_tmp[28] ^ din_tmp[26] ^ din_tmp[25] ^ din_tmp[23] ^ din_tmp[22] ^ din_tmp[19] ^ din_tmp[18] ^ din_tmp[17] ^ din_tmp[15] ^ din_tmp[14] ^ din_tmp[11] ^ din_tmp[10] ^ din_tmp[6] ^ init_val_tmp[1] ^ init_val_tmp[2] ^ init_val_tmp[3] ^ init_val_tmp[6] ^ init_val_tmp[7] ^ init_val_tmp[9] ^ init_val_tmp[10] ^ init_val_tmp[12] ^ init_val_tmp[14] ^ init_val_tmp[15];
   assign next_crc[12] = din_tmp[31] ^ din_tmp[29] ^ din_tmp[28] ^ din_tmp[24] ^ din_tmp[23] ^ din_tmp[22] ^ din_tmp[18] ^ din_tmp[16] ^ din_tmp[15] ^ din_tmp[8] ^ din_tmp[7] ^ din_tmp[4] ^ din_tmp[0] ^ init_val_tmp[0] ^ init_val_tmp[2] ^ init_val_tmp[6] ^ init_val_tmp[7] ^ init_val_tmp[8] ^ init_val_tmp[12] ^ init_val_tmp[13] ^ init_val_tmp[15];
   assign next_crc[13] = din_tmp[30] ^ din_tmp[29] ^ din_tmp[25] ^ din_tmp[24] ^ din_tmp[23] ^ din_tmp[19] ^ din_tmp[17] ^ din_tmp[16] ^ din_tmp[9] ^ din_tmp[8] ^ din_tmp[5] ^ din_tmp[1] ^ init_val_tmp[0] ^ init_val_tmp[1] ^ init_val_tmp[3] ^ init_val_tmp[7] ^ init_val_tmp[8] ^ init_val_tmp[9] ^ init_val_tmp[13] ^ init_val_tmp[14];
   assign next_crc[14] = din_tmp[31] ^ din_tmp[30] ^ din_tmp[26] ^ din_tmp[25] ^ din_tmp[24] ^ din_tmp[20] ^ din_tmp[18] ^ din_tmp[17] ^ din_tmp[10] ^ din_tmp[9] ^ din_tmp[6] ^ din_tmp[2] ^ init_val_tmp[1] ^ init_val_tmp[2] ^ init_val_tmp[4] ^ init_val_tmp[8] ^ init_val_tmp[9] ^ init_val_tmp[10] ^ init_val_tmp[14] ^ init_val_tmp[15];
   assign next_crc[15] = din_tmp[31] ^ din_tmp[27] ^ din_tmp[26] ^ din_tmp[25] ^ din_tmp[21] ^ din_tmp[19] ^ din_tmp[18] ^ din_tmp[11] ^ din_tmp[10] ^ din_tmp[7] ^ din_tmp[3] ^ init_val_tmp[2] ^ init_val_tmp[3] ^ init_val_tmp[5] ^ init_val_tmp[9] ^ init_val_tmp[10] ^ init_val_tmp[11] ^ init_val_tmp[15];

endmodule


