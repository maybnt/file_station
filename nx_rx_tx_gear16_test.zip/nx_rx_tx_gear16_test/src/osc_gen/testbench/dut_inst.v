    osc_gen u_osc_gen(.hf_out_en_i(hf_out_en_i),
        .hf_clk_out_o(hf_clk_out_o));
