component osc_gen is
    port(
        hf_out_en_i: in std_logic;
        hf_clk_out_o: out std_logic
    );
end component;

__: osc_gen port map(
    hf_out_en_i=>,
    hf_clk_out_o=>
);
