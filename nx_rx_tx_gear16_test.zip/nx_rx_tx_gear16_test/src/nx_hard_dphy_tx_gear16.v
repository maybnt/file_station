`define DSI_WITH_DCS
module nx_hard_dphy_tx_gear16  #(
   parameter CN            = "10000",     //"11111"--1, "00000"--2, "10000"--3, "11000"--4, "11100"--5, "01110"--6, "00111"--7, "10011"--8 
   parameter CM            = "10010000",  //"11100000"->"11101111"-- 16->31,  "11000000"->"11011111"-- 32->63,  "10000000"->"10111111"-- 64->127  
   parameter CO            = "000")       //"000"--1, "001"--2, "010"--4, "011"--8, "111"--16     
(                                         //line rate = Fref/CN * CM/CO = 75/3 * 80/1 = 2000Mbps           Fref/CN---[24M--50M]
   input  wire       osc_75m,
   input  wire       rstn,
   input  wire       dcs_clk,
   
   inout  wire       d0_p_o, 
   inout  wire       d0_n_o,
   inout  wire       d1_p_o,
   inout  wire       d1_n_o,
   inout  wire       d2_p_o,
   inout  wire       d2_n_o,
   inout  wire       d3_p_o,
   inout  wire       d3_n_o,
   inout  wire       clk_p_o,
   inout  wire       clk_n_o 
);
   
   wire [63:0] hs_data_out;    
   wire        hs_data_en;   
   wire [1:0]  lp_data;    
   
   wire        dcs_init_done;
   wire [1:0]  lp_clk; 
   wire [3:0]  lp_tx_data_p_i;
   wire [3:0]  lp_tx_data_n_i;   
   wire        txclk_hsen; 
   wire        hsxx_clk_en;             
   wire        txclk_hsgate; 
   wire        txclk_lp_p;            
   wire        txclk_lp_n;            
   wire        dphy_lock;
   wire        tx_byte_clk;     
   wire [3:0]  data_p_io;
   wire [3:0]  data_n_io;             

`ifdef DSI_WITH_DCS                          
   dsi_color_bar_1080x1920_gear16 #(
      .FRAME_WIDTH          (12'd405            ),       
      .FRAME_HEIGHT         (14'd1920           ),    
      .TOTAL_WIDTH          (12'd600            ),    
      .TOTAL_HEIGHT         (14'd1980           ),
      .VBP                  (14'd20             ))    
   dsi_color_bar_local (                        
      .clk                  (tx_byte_clk        ),
      .rstn                 (dcs_init_done      ), 
      .lp_data              (lp_data            ),                  
      .hs_data_en           (hs_data_en         ), 
      .data_out             (hs_data_out        )  
   );
   
   dcs_gen dcs_gen_inst(
      .rstn                 (dphy_lock          ),         
      .clk                  (dcs_clk            ),                     
      .txclk_hsen           (txclk_hsen         ),                     
      .hsxx_clk_en          (hsxx_clk_en        ),                     
      .txclk_lp_p           (lp_clk[1]          ),                     
      .txclk_lp_n           (lp_clk[0]          ),                     
      .dcs_init_done        (dcs_init_done      ),                     
      .lp                   (lp                 ),                     
      .ln                   (ln                 )                      
   );       

   assign {lp_tx_data_p_i[0],lp_tx_data_n_i[0]} = dcs_init_done ? lp_data : {lp,ln};     
   assign {lp_tx_data_p_i[1],lp_tx_data_n_i[1]} = dcs_init_done ? lp_data : 2'b11;    
   assign {lp_tx_data_p_i[2],lp_tx_data_n_i[2]} = dcs_init_done ? lp_data : 2'b11;    
   assign {lp_tx_data_p_i[3],lp_tx_data_n_i[3]} = dcs_init_done ? lp_data : 2'b11;    
    

`else   
   csi_raw12_4lane_gen_64b #(                                             
      .IDLE_WAIT_TIME       (16'd1000           ),                        
      .FRAME_WIDTH          (12'd1920           ),                               
      .FRAME_HEIGHT         (12'd1080           ),                               
      .TOTAL_WIDTH          (12'd2400           ), 
      .TOTAL_PIXELS         (24'd2700000        ), 
      .INTERV_SOF_DATA      (12'd150            ), 
      .INTERV_DATA_EOF      (12'd150            ))  
   csi_raw12_4lane_gen_inst1 (                                                 
      .clk                  (tx_byte_clk        ),              
      .rstn                 (rstn               ),               
      .lp_clk               (lp_clk             ),              
      .hs_clk_en            (txclk_hsen         ),              
      .hsxx_clk_en          (hsxx_clk_en        ),              
      .lp_data              (lp_data            ),              
      .hs_data_en           (hs_data_en         ),              
      .data_out             (hs_data_out        )               
   );  
   
   assign {lp_tx_data_p_i[0],lp_tx_data_n_i[0]} = lp_data;     
   assign {lp_tx_data_p_i[1],lp_tx_data_n_i[1]} = lp_data;     
   assign {lp_tx_data_p_i[2],lp_tx_data_n_i[2]} = lp_data;     
   assign {lp_tx_data_p_i[3],lp_tx_data_n_i[3]} = lp_data; 
       
`endif    
   
   assign {d3_p_o,d2_p_o,d1_p_o,d0_p_o} = data_p_io;
   assign {d3_n_o,d2_n_o,d1_n_o,d0_n_o} = data_n_io;
   assign txclk_hsgate = ~hsxx_clk_en; 
   assign txclk_lp_p = lp_clk[1];
   assign txclk_lp_n = lp_clk[0];
   
   csi_transmitter  #(                                                                                                   
      .CN                   (CN                 ),                                       
      .CO                   (CO                 ),                                       
      .CM                   (CM                 ))                                       
   csi_transmitter_inst (
      .sync_clk_i           (osc_75m            ),   
      .sync_rst_i           (!rstn              ),       
      .lmmi_clk_i           (1'b0               ),
      .lmmi_resetn_i        (1'b0               ),   
      .lmmi_wdata_i         (4'h0               ),
      .lmmi_wr_rdn_i        (1'b0               ),
      .lmmi_offset_i        (5'h0               ),    
      .lmmi_request_i       (1'b0               ),    
      .lmmi_ready_o         (                   ),    
      .lmmi_rdata_o         (                   ),
      .lmmi_rdata_valid_o   (                   ),
      .hs_tx_en_i           (1'b1               ),                                     
      .hs_tx_data_i         (hs_data_out        ),                                    
      .hs_tx_data_en_i      (hs_data_en         ),                                    
      .lp_tx_data_p_i       (lp_tx_data_p_i     ),                                    
      .lp_tx_data_n_i       (lp_tx_data_n_i     ),                                    
      .lp_tx_data_en_i      (~hs_data_en        ),                                    
      .hs_tx_clk_en_i       (txclk_hsen         ),                                    
      .txclk_hsgate_i       (txclk_hsgate       ),                                    
      .lp_tx_clk_p_i        (txclk_lp_p         ),  
      .lp_tx_clk_n_i        (txclk_lp_n         ),  
      .clk_p_io             (clk_p_o            ),
      .clk_n_io             (clk_n_o            ),
      .data_p_io            (data_p_io          ),
      .data_n_io            (data_n_io          ),
      .usrstdby_i           (1'b0               ),    
      .pd_dphy_i            (!rstn              ), 
      .pll_lock_o           (dphy_lock          ),
      .clk_byte_o           (tx_byte_clk        ),
      .ready_o              (                   )                                                                   
   );   
   
endmodule