// --------------------------------------------------------------------
// >>>>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
// --------------------------------------------------------------------
// Copyright (c) 2013 by Lattice Semiconductor Corporation
// --------------------------------------------------------------------
//
// Permission:
//
//   Lattice Semiconductor grants permission to use this code for use
//   in synthesis for any Lattice programmable logic product.  Other
//   use of this code, including the selling or duplication of any
//   portion is strictly prohibited.
//
// Disclaimer:
//
//   This VHDL or Verilog source code is intended as a design reference
//   which illustrates how these types of functions can be implemented.
//   It is the user's responsibility to verify their design for
//   consistency and functionality through the use of formal
//   verification methods.  Lattice Semiconductor provides no warranty
//   regarding the use or functionality of this code.
//
// --------------------------------------------------------------------
//           
//                     Lattice Semiconductor Corporation
//                     5555 NE Moore Court
//                     Hillsboro, OR 97214
//                     U.S.A
//
//                     TEL: 1-800-Lattice (USA and Canada)
//                          408-826-6000 (other locations)
//
//                     web: http://www.latticesemi.com/
//                     email: techsupport@latticesemi.com
//
// --------------------------------------------------------------------
//
// parallel2byte.v
// 
//
// --------------------------------------------------------------------
//
// Revision History :
// --------------------------------------------------------------------
//   Ver  :| Author            :| Mod. Date :| Changes Made:
//------------------------------------------------------------------------------------------------------------------------------------------
`timescale 1ns/1ps 
module csi_receiver_analyzer (
   input  wire        rstn,
   input  wire        rx_byte_clk, 
   input  wire        byte_data_en,
   input  wire [63:0] byte_data 
);  

   reg         byte_data_en_dly;
   reg  [63:0] byte_data_dly; 
   reg         csi_rx_sot;
   reg         csi_rx_sot_dly;       
   reg  [5:0]  csi_rx_dt; 
   reg  [1:0]  csi_vc;
   reg  [15:0] csi_wc;  
   reg  [7:0]  csi_ecc;  
   
   wire [23:0] ecc_cal_in; 
   wire [7:0]  ecc_cal_out;
   reg         ecc_err;   
   
   wire [63:0] crc_din;
   reg         crc_din_en; 
   reg         crc_din_en_dly;    
   reg  [12:0] crc_din_cnt;
   reg         crc_din_last32b_en; 
   reg         crc_din_last32b_en_dly;       
   wire [15:0] crc_out_tmp; 
   wire [15:0] crc_out_last32b;
   reg         crc_err;
   
   reg  [15:0] csi_wc_0;   
   reg  [15:0] csi_wc_1;   
   reg  [15:0] csi_wc_2;    
   reg  [11:0] line_cnt_0;
   reg  [11:0] line_cnt_1;
   reg  [11:0] line_cnt_2;
   
//write area
   always @(posedge rx_byte_clk or negedge rstn) begin                            
      if (rstn == 1'b0) begin                         
         byte_data_en_dly <= 0; 
         byte_data_dly <= 0;
         csi_rx_sot <= 0; 
         csi_rx_sot_dly <= 0;         
         csi_rx_dt <= 0;   
         csi_vc <= 0;
         csi_wc <= 0;  
         csi_ecc <= 0; 
         ecc_err <= 0;
      end 
      else begin                                                  
         byte_data_en_dly <= byte_data_en;  
         byte_data_dly <= byte_data;       
         csi_rx_sot <= ~byte_data_en_dly && byte_data_en; 
         csi_rx_sot_dly <= csi_rx_sot;          
         if (csi_rx_sot) begin
            csi_rx_dt <= byte_data[5:0]; 
            csi_vc <= byte_data[7:6];  
            csi_wc <= {byte_data[39:32],byte_data[23:16]};
            csi_ecc <= byte_data[55:48];
         end
         if (csi_rx_sot_dly)  
            ecc_err <= csi_ecc != ecc_cal_out; 
      end 
   end   
   
   assign ecc_cal_in = {csi_wc,csi_vc,csi_rx_dt};    
   
   ecc_cal ecc_cal (                  
      .clk            (rx_byte_clk     ),    
      .rstn           (rstn            ),   
      .din            (ecc_cal_in      ), 
      .ecc_out        (ecc_cal_out     )  
   );              
   
   assign crc_din = {byte_data[55:48],byte_data[39:32],byte_data[23:16],byte_data[7:0],byte_data_dly[63:56],byte_data_dly[47:40],byte_data_dly[31:24],byte_data_dly[15:8]};
   
   always @(posedge rx_byte_clk or negedge rstn) begin                            
      if (rstn == 1'b0) begin                         
         crc_din_en <= 0; 
         crc_din_en_dly <= 0; 
         crc_din_cnt <= 0;   
         crc_din_last32b_en <= 0;
         crc_din_last32b_en_dly <= 0; 
         crc_err <= 0;
      end 
      else begin                                                  
         if (csi_rx_sot && byte_data[5:1] != 0)  
            crc_din_en <= 1; 
         else if (crc_din_cnt == csi_wc[15:3] - 1)  
            crc_din_en <= 0; 
         crc_din_en_dly <= crc_din_en;     
         if (crc_din_en)
            crc_din_cnt <= crc_din_cnt + 1; 
         else
            crc_din_cnt <= 0;
         crc_din_last32b_en <= (crc_din_cnt == csi_wc[15:3] - 1) && csi_wc[2]; 
         crc_din_last32b_en_dly <= crc_din_last32b_en;     
         crc_err <= (crc_din_en_dly && ~crc_din_en && ~crc_din_last32b_en && crc_out_tmp != crc_din[15:0]) || (crc_din_last32b_en_dly && crc_out_last32b != {byte_data_dly[23:16],byte_data_dly[7:0]});                    
      end 
   end   
   
   crc16_64b crc16_64b_inst (                           
      .clk      (rx_byte_clk        ),                       
      .rstn     (rstn               ),              
      .init     (csi_rx_sot         ),             
      .din      (crc_din            ),             
      .din_en   (crc_din_en         ),             
      .crc      (crc_out_tmp        )
   );                         
   
   crc16_32b_one_cycle crc16_32b_one_cycle (
      .clk      (rx_byte_clk        ),       
      .rstn     (rstn               ),       
      .init_val (crc_out_tmp        ),       
      .din      (crc_din[31:0]      ),       
      .din_en   (crc_din_last32b_en ),       
      .crc      (crc_out_last32b    )        
   );
   
   always @(posedge rx_byte_clk or negedge rstn) begin                            
      if (rstn == 1'b0) begin  
      	 csi_wc_0 <= 0;                        
         csi_wc_1 <= 0; 
         csi_wc_2 <= 0;  
         line_cnt_0 <= 0;  
         line_cnt_1 <= 0;  
         line_cnt_2 <= 0;    
      end 
      else begin  
         if (csi_rx_sot_dly) begin
            if (csi_vc == 0 && csi_rx_dt[5:1] != 0)
               csi_wc_0 <= csi_wc;     
            if (csi_vc == 1 && csi_rx_dt[5:1] != 0)
               csi_wc_1 <= csi_wc;     
            if (csi_vc == 2 && csi_rx_dt[5:1] != 0)
               csi_wc_2 <= csi_wc;   
      	 end                                            
         if (csi_rx_sot_dly) begin
            if (csi_vc == 0 && csi_rx_dt[5:1] == 0)
               line_cnt_0 <= 0;  
            else if (csi_vc == 0 && csi_rx_dt[3:0] >= 4)
               line_cnt_0 <= line_cnt_0 + 1; 
            if (csi_vc == 1 && csi_rx_dt[5:1] == 0)
               line_cnt_1 <= 0;  
            else if (csi_vc == 1 && csi_rx_dt[3:0] >= 4)
               line_cnt_1 <= line_cnt_1 + 1;    
            if (csi_vc == 2 && csi_rx_dt[5:1] == 0)
               line_cnt_2 <= 0;  
            else if (csi_vc == 2 && csi_rx_dt[3:0] >= 4)
               line_cnt_2 <= line_cnt_2 + 1;    
         end
      end 
   end   
   
	 
endmodule

