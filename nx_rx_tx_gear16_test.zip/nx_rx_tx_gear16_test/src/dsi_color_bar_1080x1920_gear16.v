`timescale 1ns/100ps 

module dsi_color_bar_1080x1920_gear16 #(
   parameter FRAME_WIDTH   = 12'd405,                       
   parameter FRAME_HEIGHT  = 14'd1920,                    
   parameter TOTAL_WIDTH   = 12'd600,                        
   parameter TOTAL_HEIGHT  = 14'd1980,
   parameter VBP           = 14'd20 
)(                      
   input  wire        clk,
   input  wire        rstn, 
   output reg  [1:0]  lp_data,                  
   output reg         hs_data_en, 
   output wire [63:0] data_out
);                    

   localparam  T_LPX_LP01           = 5'd8;
   localparam  T_HS_PREPARE_LP00    = 5'd8;   //between 50ns and 90ns !!!!
   localparam  T_HS_ZERO_HS00       = 5'd20;
   localparam  T_HS_TRAIL           = 5'd10;
   
   localparam  DSI_TX_LP            = 3'h0;   
   localparam  DSI_TX_LPX           = 3'h1;   
   localparam  DSI_TX_HS_PREPARE    = 3'h2;   
   localparam  DSI_TX_HS_ZERO       = 3'h3;   
   localparam  DSI_TX_HS_SOT        = 3'h4;   
   localparam  DSI_TX_HS_DATA       = 3'h5;   
   localparam  DSI_TX_HS_TRAIL      = 3'h6;   
   
   localparam TOTAL_WIDTH_M1 = TOTAL_WIDTH - 1;          
   localparam TOTAL_HEIGHT_M1 = TOTAL_HEIGHT - 1;           
   
   localparam HSYNC_PKG_TRIG_H_NUM = 1;                
   localparam DATA_PKG_TRIG_H_NUM  = 71;     
   localparam VSYNC_PKG_TRIG_V_NUM = TOTAL_HEIGHT - FRAME_HEIGHT - VBP; 
   localparam DATA_PKG_ST_V_NUM = TOTAL_HEIGHT - FRAME_HEIGHT;   
   localparam COLOR_BAR_WIDTH_DIV9 = FRAME_WIDTH/9;
                                                        
   reg  [13:0] vcnt;	                                                
   reg  [11:0] hcnt;   
   reg         vsync_pkg_tx_en;
   reg         hsync_pkg_tx_en; 
   reg         data_pkg_tx_en ;
   
   reg  [2:0]  dsi_tx_hs_sm;  
   reg  [11:0] dsi_tx_hs_sm_cnt;  
   reg         dsi_tx_lpx_done;
   reg         dsi_tx_hs_prepare_done;                   
   reg         dsi_tx_hs_zero_done;                      
   reg         dsi_tx_hs_sot_done;                       
   reg         dsi_tx_hs_data_done;                      
   reg         dsi_tx_hs_trail_done; 
          
   reg         rgb_gen_en; 
   reg         rgb_gen_en_dly;
   reg  [11:0] rgb_gen_en_cnt;
   reg  [1:0]  data_sel;
   reg         line_sel;
   reg  [7:0]  r;
   reg  [7:0]  g;
   reg  [7:0]  b;
   reg  [63:0] crc_din; 
   reg  [63:0] crc_din_dly;       
   reg         crc_din_en_64;  
   wire [15:0] crc_out_64; 
   wire [15:0] crc_out; 
   reg  [15:0] crc_out_dly; 
   reg  [23:0] ecc_din;  
   wire [7:0]  ecc_out;    
   wire [15:0] wc;  
   
   reg  [15:0] dsi_byte_d3;
   reg  [15:0] dsi_byte_d2;
   reg  [15:0] dsi_byte_d1;
   reg  [15:0] dsi_byte_d0;    
   
   assign wc = FRAME_WIDTH*8;
   
   always @ (posedge clk or negedge rstn) begin
      if (!rstn) begin
         hcnt <= 0;
         vcnt <= 0; 
         vsync_pkg_tx_en <= 0;
         hsync_pkg_tx_en <= 0;
         data_pkg_tx_en <= 0;
      end
      else begin
         if (hcnt == TOTAL_WIDTH_M1) begin
            hcnt <= 0;		 
            if (vcnt == TOTAL_HEIGHT_M1)
               vcnt <= 0; 
            else
               vcnt <= vcnt + 1; 
         end      
         else 
            hcnt <= hcnt +1;	
         
         if (hcnt == HSYNC_PKG_TRIG_H_NUM && vcnt == VSYNC_PKG_TRIG_V_NUM)
            vsync_pkg_tx_en <= 1;
         else if (dsi_tx_hs_trail_done)
            vsync_pkg_tx_en <= 0;
         if (hcnt == HSYNC_PKG_TRIG_H_NUM && vcnt != VSYNC_PKG_TRIG_V_NUM)
            hsync_pkg_tx_en <= 1;
         else if (dsi_tx_hs_trail_done)
            hsync_pkg_tx_en <= 0;
         if (hcnt == DATA_PKG_TRIG_H_NUM && vcnt >= DATA_PKG_ST_V_NUM)
            data_pkg_tx_en <= 1;
         else if (dsi_tx_hs_trail_done)
            data_pkg_tx_en <= 0;
      end
   end

   always @(posedge clk or negedge rstn) begin             
      if (!rstn) begin                    
         dsi_tx_hs_sm <= DSI_TX_LP;   
      end  
      else begin   
         case (dsi_tx_hs_sm)
            DSI_TX_LP : begin 
               if (vsync_pkg_tx_en | hsync_pkg_tx_en | data_pkg_tx_en)                
                  dsi_tx_hs_sm <= DSI_TX_LPX;       
            end
            DSI_TX_LPX : begin  
               if (dsi_tx_lpx_done) 
                  dsi_tx_hs_sm <= DSI_TX_HS_PREPARE;
            end 
            DSI_TX_HS_PREPARE : begin    
               if (dsi_tx_hs_prepare_done) 
                  dsi_tx_hs_sm <= DSI_TX_HS_ZERO;  
            end  
            DSI_TX_HS_ZERO : begin    
               if (dsi_tx_hs_zero_done) 
                  dsi_tx_hs_sm <= DSI_TX_HS_SOT; 
            end                                       
            DSI_TX_HS_SOT : begin 
               if (dsi_tx_hs_sot_done) begin  
                  dsi_tx_hs_sm <= data_pkg_tx_en ? DSI_TX_HS_DATA : DSI_TX_HS_TRAIL;
               end 
            end
            DSI_TX_HS_DATA : begin
               if (dsi_tx_hs_data_done)
                  dsi_tx_hs_sm <= DSI_TX_HS_TRAIL;   
            end 
            DSI_TX_HS_TRAIL : begin  
               if (dsi_tx_hs_trail_done) 
                  dsi_tx_hs_sm <= DSI_TX_LP;      
            end 
         endcase
      end
   end
   
   always @ (posedge clk or negedge rstn) begin
      if (!rstn) begin  
         dsi_tx_hs_sm_cnt <= 0; 
         dsi_tx_lpx_done <= 0;
         dsi_tx_hs_prepare_done <= 0;     
         dsi_tx_hs_zero_done <= 0;         
         dsi_tx_hs_sot_done <= 0;  
         dsi_tx_hs_data_done <= 0; 
         dsi_tx_hs_trail_done <= 0;
      end
      else begin
         if (dsi_tx_hs_sm == DSI_TX_LP || dsi_tx_lpx_done || dsi_tx_hs_prepare_done || dsi_tx_hs_zero_done || dsi_tx_hs_sot_done || dsi_tx_hs_data_done || dsi_tx_hs_trail_done) 
            dsi_tx_hs_sm_cnt <= 0;   
         else 
            dsi_tx_hs_sm_cnt <= dsi_tx_hs_sm_cnt + 1;     
         dsi_tx_lpx_done <= (dsi_tx_hs_sm_cnt == T_LPX_LP01 - 2) && (dsi_tx_hs_sm == DSI_TX_LPX);
         dsi_tx_hs_prepare_done <= (dsi_tx_hs_sm_cnt == T_HS_PREPARE_LP00 - 2) && (dsi_tx_hs_sm == DSI_TX_HS_PREPARE);                                   
         dsi_tx_hs_zero_done <= (dsi_tx_hs_sm_cnt == T_HS_ZERO_HS00 - 2) && (dsi_tx_hs_sm == DSI_TX_HS_ZERO);                                            
         dsi_tx_hs_sot_done <= dsi_tx_hs_zero_done;                                              
         dsi_tx_hs_data_done <= (dsi_tx_hs_sm_cnt == FRAME_WIDTH - 1) && (dsi_tx_hs_sm == DSI_TX_HS_DATA);
         dsi_tx_hs_trail_done <= (dsi_tx_hs_sm_cnt == T_HS_TRAIL - 2) && (dsi_tx_hs_sm == DSI_TX_HS_TRAIL);                                              
      end
   end
   
   
   always @ (posedge clk or negedge rstn) begin
      if (!rstn) begin
         rgb_gen_en <= 0; 
         rgb_gen_en_dly <= 0;
         rgb_gen_en_cnt <= 0; 
         data_sel <= 0;    
         line_sel <= 0; 
  			 r <= 8'h00;
         g <= 8'h00;
         b <= 8'h00; 
         crc_din_en_64 <= 0; 
         crc_din <= 0; 
         crc_din_dly <= 0;  
         ecc_din <= 0;
         crc_out_dly <= 0;
      end
      else begin
         if ((dsi_tx_hs_sm_cnt == T_HS_ZERO_HS00 - 2) && (dsi_tx_hs_sm == DSI_TX_HS_ZERO) && data_pkg_tx_en)
            rgb_gen_en <= 1;  
         else if ((dsi_tx_hs_sm_cnt == FRAME_WIDTH - 4) && (dsi_tx_hs_sm == DSI_TX_HS_DATA)) 
            rgb_gen_en <= 0; 
         rgb_gen_en_dly <= rgb_gen_en;
         if (rgb_gen_en) 
            rgb_gen_en_cnt <= rgb_gen_en_cnt + 1;
         else 
            rgb_gen_en_cnt <= 0;
         if (rgb_gen_en_dly) 
            data_sel <= data_sel[1] ? 0 : (data_sel + 1);    
         else 
            data_sel <= 0;   
         if (vsync_pkg_tx_en) 
            line_sel <= 0;   
         else if (data_pkg_tx_en & dsi_tx_hs_trail_done)
            line_sel <= ~line_sel;   
         if (vcnt <= DATA_PKG_ST_V_NUM + 1) begin
            r <= 8'hff;
            g <= 8'h00;
            b <= 8'h00;
         end   
         else if (vcnt >= TOTAL_HEIGHT_M1 - 1) begin
            r <= 8'h00;
            g <= 8'h00;
            b <= 8'hff;
         end
         else begin
            case (rgb_gen_en_cnt)
               (0): begin
                  r <= 8'h00;
                  g <= 8'h00;
                  b <= 8'hff;
               end
               (1): begin
                  r <= 8'h00;
                  g <= 8'h00;
                  b <= 8'h00;
               end
               (COLOR_BAR_WIDTH_DIV9): begin
                  r <= 8'hff;
                  g <= 8'h00;
                  b <= 8'h00;
               end
               (2*COLOR_BAR_WIDTH_DIV9): begin           
                  r <= 8'h00;
                  g <= 8'hff;
                  b <= 8'h00;
               end
               (3*COLOR_BAR_WIDTH_DIV9): begin           
                  r <= 8'h00;
                  g <= 8'h00;
                  b <= 8'hff;
               end
               (4*COLOR_BAR_WIDTH_DIV9): begin           
                  r <= 8'hff;
                  g <= 8'hff;
                  b <= 8'h00;
               end
               (5*COLOR_BAR_WIDTH_DIV9): begin           
                  r <= 8'hff;
                  g <= 8'h00;
                  b <= 8'hff;
               end
               (6*COLOR_BAR_WIDTH_DIV9): begin           
                  r <= 8'h00;
                  g <= 8'hff;
                  b <= 8'hff;
               end
               (7*COLOR_BAR_WIDTH_DIV9): begin           
                  r <= 8'hff;
                  g <= 8'hff;
                  b <= 8'hff;
               end        
               (8*COLOR_BAR_WIDTH_DIV9): begin       
                  r <= 8'h80;                        
                  g <= 8'h80;                        
                  b <= 8'h80;                        
               end 
               (FRAME_WIDTH - 1): begin       
                  r <= 8'hff;                        
                  g <= 8'h00;                        
                  b <= 8'h00;                        
               end                                   
            endcase
         end
         crc_din_en_64 <= rgb_gen_en_dly;
         crc_din <= data_sel[1] ? {b,g,r,b,g,r,b,g} : data_sel[0] ? {r,b,g,r,b,g,r,b} : {g,r,b,g,r,b,g,r}; //data_sel[1] ? 32'h0000ff00 : data_sel[0] ? 32'h00ff0000 : 32'hff0000ff;   //
         crc_din_dly <= crc_din;    
         crc_out_dly <= crc_out_64;
         if (vsync_pkg_tx_en)
            ecc_din <= {24'h000001}; 
         else if (hsync_pkg_tx_en)                                          
            ecc_din <= {24'h000021}; 
         else if (data_pkg_tx_en)   
            ecc_din <= {wc,8'h3e};       
      end
   end
   
   crc16_64b crc16_64b_inst (                           
      .clk      (clk           ),                       
      .rstn     (rstn          ),
      .init     (dsi_tx_hs_zero_done ),
      .din      (crc_din       ),
      .din_en   (crc_din_en_64 ),
      .crc      (crc_out_64    )
   );
   
   ecc_gen ecc_gen_inst (
      .clk      (clk           ),        
      .rstn     (rstn          ),        
      .din      (ecc_din       ),
      .ecc_out  (ecc_out       )
   );
   
   always @(posedge clk or negedge rstn) begin                                                           
      if (!rstn) begin  
         dsi_byte_d3 <= 8'h00;       
         dsi_byte_d2 <= 8'h00;       
         dsi_byte_d1 <= 8'h00;
         dsi_byte_d0 <= 8'h00;
      end                                                                                                  
      else begin
         case (dsi_tx_hs_sm)
            DSI_TX_LP         : begin                                                                                                             
               dsi_byte_d3 <= 0; dsi_byte_d2 <= 0; dsi_byte_d1 <= 0; dsi_byte_d0 <= 0; end                                                
            DSI_TX_LPX        : begin                                                                                                             
               dsi_byte_d3 <= 0; dsi_byte_d2 <= 0; dsi_byte_d1 <= 0; dsi_byte_d0 <= 0; end                                                
            DSI_TX_HS_PREPARE : begin 
               dsi_byte_d3 <= 0; dsi_byte_d2 <= 0; dsi_byte_d1 <= 0; dsi_byte_d0 <= 0; end 
            DSI_TX_HS_ZERO    : begin 
               dsi_byte_d3 <= 0; dsi_byte_d2 <= 0; dsi_byte_d1 <= 0; dsi_byte_d0 <= 0; end 
            DSI_TX_HS_SOT     : begin 
            	dsi_byte_d3 <= {ecc_out,8'hb8}; dsi_byte_d2 <= {ecc_din[23:16],8'hb8}; dsi_byte_d1 <= {ecc_din[15:8],8'hb8}; dsi_byte_d0 <= {ecc_din[7:0],8'hb8}; end  
            DSI_TX_HS_DATA    : begin 
               if (dsi_tx_hs_data_done) begin
                  dsi_byte_d3 <= 16'hffff;           dsi_byte_d2 <= 16'hffff;          dsi_byte_d1 <= {8'hff,crc_out[15:8]};  dsi_byte_d0 <= {8'hff,crc_out[7:0]}; 
               end
               else begin
                  dsi_byte_d3 <= {crc_din[63:56],crc_din[31:24]};  dsi_byte_d2 <= {crc_din[55:48],crc_din[23:16]}; dsi_byte_d1 <= {crc_din[47:40],crc_din[15:8]};  dsi_byte_d0 <= {crc_din[39:32],crc_din[7:0]}; 
               end
            end  
            DSI_TX_HS_TRAIL   : begin dsi_byte_d3 <= 16'hffff; dsi_byte_d2 <= 16'hffff; dsi_byte_d1 <= 16'hffff;  dsi_byte_d0 <= 16'hffff; end  
         endcase                                                                                              
      end                                                                                                    
   end                                                                                                         
   
   always @(posedge clk or negedge rstn) begin
      if(!rstn) begin 
         lp_data <= 3;
         hs_data_en <= 0;
      end
      else begin 
         case (dsi_tx_hs_sm)
            DSI_TX_LP         : begin lp_data <= 3;  hs_data_en <= 0; end 
            DSI_TX_LPX        : begin lp_data <= 1;  hs_data_en <= 0; end  
            DSI_TX_HS_PREPARE : begin lp_data <= 0;  hs_data_en <= 0; end  
            DSI_TX_HS_ZERO    : begin lp_data <= 0;  hs_data_en <= 1; end  
            DSI_TX_HS_SOT     : begin lp_data <= 0;  hs_data_en <= 1; end  
            DSI_TX_HS_DATA    : begin lp_data <= 0;  hs_data_en <= 1; end  
            DSI_TX_HS_TRAIL   : begin lp_data <= 0;  hs_data_en <= 1; end  
         endcase
      end
   end
   
   assign data_out = {dsi_byte_d3,dsi_byte_d2,dsi_byte_d1,dsi_byte_d0};               

   
endmodule 

