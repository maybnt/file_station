// --------------------------------------------------------------------
// >>>>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
// --------------------------------------------------------------------
// Copyright (crc) 2013 by Lattice Semiconductor Corporation
// --------------------------------------------------------------------
//
// Permission:
//
//   Lattice Semiconductor grants permission to use this code for use
//   in synthesis for any Lattice programmable logic product.  Other
//   use of this code, including the selling or duplication of any
//   portion is strictly prohibited.
//
// Disclaimer:
//
//   This VHDL or Verilog source code is intended as a design reference
//   which illustrates how these types of functions can be implemented.
//   It is the user's responsibility to verify their design for
//   consistency and functionality through the use of formal
//   verification methods.  Lattice Semiconductor provides no warranty
//   regarding the use or functionality of this code.
//
// --------------------------------------------------------------------
//           
//                     Lattice Semiconductor Corporation
//                     5555 NE Moore Court
//                     Hillsboro, OR 97214
//                     U.S.A
//
//                     TEL: 1-800-Lattice (USA and Canada)
//                          408-826-6000 (other locations)
//
//                     web: http://www.latticesemi.com/
//                     email: techsupport@latticesemi.com
//
// --------------------------------------------------------------------
//
// MIPI DPHY TX Design
// 
`timescale 1ns/100ps 

module ecc_cal (
   input  wire        clk,
   input  wire        rstn,
   input  wire [23:0] din,
   output wire [7:0]  ecc_out
);
   
   wire [7:0] ecc_cal;
   
   assign ecc_out = ecc_cal;

   assign ecc_cal[0] = din[0]^din[1]^din[2]^din[4]^din[5]^din[7]^din[10]^din[11]^din[13]^din[16]^din[20]^din[21]^din[22]^din[23];                              
   assign ecc_cal[1] = din[0]^din[1]^din[3]^din[4]^din[6]^din[8]^din[10]^din[12]^din[14]^din[17]^din[20]^din[21]^din[22]^din[23];                              
   assign ecc_cal[2] = din[0]^din[2]^din[3]^din[5]^din[6]^din[9]^din[11]^din[12]^din[15]^din[18]^din[20]^din[21]^din[22];                             
   assign ecc_cal[3] = din[1]^din[2]^din[3]^din[7]^din[8]^din[9]^din[13]^din[14]^din[15]^din[19]^din[20]^din[21]^din[23];                             
   assign ecc_cal[4] = din[4]^din[5]^din[6]^din[7]^din[8]^din[9]^din[16]^din[17]^din[18]^din[19]^din[20]^din[22]^din[23];                                            
   assign ecc_cal[5] = din[10]^din[11]^din[12]^din[13]^din[14]^din[15]^din[16]^din[17]^din[18]^din[19]^din[21]^din[22]^din[23];               
   assign ecc_cal[6] = 0;              
   assign ecc_cal[7] = 0;              

endmodule


