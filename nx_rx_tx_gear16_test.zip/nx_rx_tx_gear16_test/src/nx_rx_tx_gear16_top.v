module nx_rx_tx_gear16_top  #(
   parameter CN            = "10000",     //"11111"--1, "00000"--2, "10000"--3, "11000"--4, "11100"--5, "01110"--6, "00111"--7, "10011"--8 
   parameter CM            = "10010000",  //"11100000"->"11101111"-- 16->31,  "11000000"->"11011111"-- 32->63,  "10000000"->"10111111"-- 64->127  
   parameter CO            = "000")       //"000"--1, "001"--2, "010"--4, "011"--8, "111"--16     
(                                         //line rate = Fref/CN * CM/CO = 75/3 * 80/1 = 2000Mbps
   input  wire       clk_n_i,                    
   input  wire       clk_p_i,                    
   input  wire       d0_n_i,                     
   input  wire       d0_p_i,                     
   input  wire       d1_n_i,                     
   input  wire       d1_p_i,                     
   input  wire       d2_n_i,      
   input  wire       d2_p_i,      
   input  wire       d3_n_i,       
   input  wire       d3_p_i,      
   
   inout  wire       d0_p_o, 
   inout  wire       d0_n_o,
   inout  wire       d1_p_o,
   inout  wire       d1_n_o,
   inout  wire       d2_p_o,
   inout  wire       d2_n_o,
   inout  wire       d3_p_o,
   inout  wire       d3_n_o,
   inout  wire       clk_p_o,
   inout  wire       clk_n_o   
);
   
   wire        osc_75m;  
   reg  [10:0] pwr_rstn_cnt = 0;
   reg         pwr_rstn;
   wire        rstn;  
   wire        clk_125m; 
   wire        clk_156m; 
   wire        clk_250m;
   wire        dcs_clk;
   
   wire        rx_byte_clk;  
   wire        sync_out;     
   wire [63:0] byte_data_out;
   
   
   osc_gen osc_gen (
     .hf_out_en_i           (1'b1               ),
     .hf_clk_out_o          (osc_75m            )
   );  
   
   always@(posedge osc_75m) begin
	    if(~pwr_rstn_cnt[10]) begin
	       pwr_rstn_cnt <= pwr_rstn_cnt + 1;
	       pwr_rstn <= 0;
	    end
	    else
	       pwr_rstn <= 1;
   end
   
   pll_gen pll_gen (                                         
      .clki_i               (osc_75m            ),                 
      .rstn_i               (pwr_rstn           ),                 
      .clkop_o              (clk_125m           ),  
      .clkos_o              (clk_156m           ),  
      .clkos2_o             (clk_250m           ),   
      .clkos3_o             (dcs_clk            ),                 
      .lock_o               (rstn               )                  
   );                                                              
   
   nx_hard_dphy_receiver_gear16 dphy_rx_inst0 (          
      .rstn                 (rstn               ), 
      .osc_75m              (osc_75m            ),       
      .clk_n_i              (clk_n_i            ),       
      .clk_p_i              (clk_p_i            ),       
      .d0_n_i               (d0_n_i             ),       
      .d0_p_i               (d0_p_i             ),       
      .d1_n_i               (d1_n_i             ),       
      .d1_p_i               (d1_p_i             ),       
      .d2_n_i               (d2_n_i             ),        
      .d2_p_i               (d2_p_i             ),
      .d3_n_i               (d3_n_i             ),
      .d3_p_i               (d3_p_i             ),
      .rx_byte_clk          (rx_byte_clk        ), 
      .sync_out             (sync_out           ),        
      .byte_data_out        (byte_data_out      )        
   );
   
   csi_receiver_analyzer csi_receiver_analyzer (           
      .rstn                 (rstn               ), 
      .rx_byte_clk          (rx_byte_clk        ), 
      .byte_data_en         (sync_out           ), 
      .byte_data            (byte_data_out      )  
   );                                       
   
   nx_hard_dphy_tx_gear16   #(                                                                                                   
      .CN                   (CN                 ),                                       
      .CO                   (CO                 ),                                       
      .CM                   (CM                 ))       
   dphy_tx_inst1 (          
      .rstn                 (rstn               ), 
      .osc_75m              (osc_75m            ),  
      .dcs_clk              (dcs_clk            ),     
      .clk_n_o              (clk_n_o            ),       
      .clk_p_o              (clk_p_o            ),       
      .d0_n_o               (d0_n_o             ),       
      .d0_p_o               (d0_p_o             ),       
      .d1_n_o               (d1_n_o             ),       
      .d1_p_o               (d1_p_o             ),       
      .d2_n_o               (d2_n_o             ),        
      .d2_p_o               (d2_p_o             ),
      .d3_n_o               (d3_n_o             ),
      .d3_p_o               (d3_p_o             ) 
   );
   
endmodule