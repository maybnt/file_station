`timescale 1ns/1ps
module nx_hard_dphy_receiver_gear16 ( 
   input  wire        rstn, 
   input  wire        osc_75m,
                      
   inout  wire        clk_n_i,
   inout  wire        clk_p_i,
                      
   inout  wire        d0_n_i,
   inout  wire        d0_p_i,
   inout  wire        d1_n_i,
   inout  wire        d1_p_i,
   inout  wire        d2_n_i,
   inout  wire        d2_p_i,
   inout  wire        d3_n_i,
   inout  wire        d3_p_i,
                      
   output wire        rx_byte_clk,
   output reg         sync_out,                                      
   output reg [63:0]  byte_data_out                                
);   
   
   wire [3:0]  d_sot_det_0;
   wire [3:0]  d_sot_det_1;
   wire [3:0]  d_sot_det_2;
   wire [3:0]  d_sot_det_3;
   reg         d_sot_det;    
   wire [3:0]  err_sync;  
   wire [15:0] bd0_mixel;   
   wire [15:0] bd1_mixel;   
   wire [15:0] bd2_mixel;   
   wire [15:0] bd3_mixel;  
   wire [63:0] din_comb; 
   reg  [15:0] din_align_0; 
   reg  [15:0] din_align_1; 
   reg  [15:0] din_align_2; 
   reg  [15:0] din_align_3;    
   wire        clk_ln;  
   wire        clk_lp;  
   wire        d0_rxlpn;
   wire        d0_rxlpp;
   
   wire        rx_byte_clk_hs;
   reg  [15:0] d0_rxlpn_dly; 
   reg  [15:0] d0_rxlpp_dly;  
   reg  [3:0]  clk_ln_dly;
   reg         clk_term_en;
   reg         hs_term_en;
   reg         hs_des_en_tmp;
   reg         hs_des_en_tmp_dly;
   wire        hs_des_en;
   reg         data_lp_rx_en;
   
   reg  [63:0] din_align_dly;        
   
   dphy_rx_wrap_gear16 dphy_rx_wrap_gear16_inst (          
      .reset_n_i            (rstn               ), 
      .refclk               (osc_75m            ),   
      .clk_p_i              (clk_p_i            ),       
      .clk_n_i              (clk_n_i            ),       
      .d0_p_io              (d0_p_i             ),       
      .d0_n_io              (d0_n_i             ),        
      .d1_p_i               (d1_p_i             ),       
      .d1_n_i               (d1_n_i             ),       
      .d2_p_i               (d2_p_i             ),       
      .d2_n_i               (d2_n_i             ),       
      .d3_p_i               (d3_p_i             ),        
      .d3_n_i               (d3_n_i             ),
      .enp_deser            (1'b0               ),   
      .clk_lp_rx_en         (1'b1               ),//(clk_lp_rx_en       ),//  
      .data_lp_rx_en        (1'b1               ),//(data_lp_rx_en      ),//
      .term_clk_en          (clk_term_en        ),//(1'b1               ),//                  
      .term_en              (hs_term_en         ),//(1'b1               ),//
      .hs_des_en            (hs_des_en          ),//(1'b1               ),// 
      .d_sot_det_0          (d_sot_det_0        ),
      .d_sot_det_1          (d_sot_det_1        ), 
      .d_sot_det_2          (d_sot_det_2        ), 
      .d_sot_det_3          (d_sot_det_3        ), 
      .err_sync             (err_sync           ),  
      .byte_clk             (rx_byte_clk        ), 
      .byte_clk_hs          (rx_byte_clk_hs     ),   
      .clk_rxlpn            (clk_ln             ),  
      .clk_rxlpp            (clk_lp             ),  
      .d0_rxlpn             (d0_rxlpn           ),   
      .d0_rxlpp             (d0_rxlpp           ),   
      .d1_rxlpn             (                   ), 
      .d1_rxlpp             (                   ), 
      .d2_rxlpn             (                   ), 
      .d2_rxlpp             (                   ), 
      .d3_rxlpn             (                   ), 
      .d3_rxlpp             (                   ), 
      .bd0_mixel            (bd0_mixel          ),   
      .bd1_mixel            (bd1_mixel          ),    
      .bd2_mixel            (bd2_mixel          ),     
      .bd3_mixel            (bd3_mixel          )
   );          

   assign din_comb = {bd3_mixel[15:0],bd2_mixel[15:0],bd1_mixel[15:0],bd0_mixel[15:0]};       
   
//   assign din_align = {bd3_mixel[7:0],bd2_mixel[7:0],bd1_mixel[7:0],bd0_mixel[7:0]};
//   assign d_sot_det = d_sot_det_0[0];    
   
   always @(posedge osc_75m or negedge rstn) begin                            
      if (rstn == 1'b0) begin                         
         clk_ln_dly <= 0;     
         clk_term_en <= 1'b0;   
      end 
      else begin                                                  
         clk_ln_dly <= {clk_ln_dly[2:0],clk_ln};       
         clk_term_en <= ~clk_ln_dly[3];     
      end 
   end   
   
   always @(posedge rx_byte_clk_hs or negedge rstn) begin                            
      if (rstn == 1'b0) begin                         
         d0_rxlpn_dly <= 16'hffff; 
         d0_rxlpp_dly <= 16'hffff;
         hs_des_en_tmp <= 1'b0;  
         hs_term_en <= 0;  
         data_lp_rx_en <= 1;     
      end 
      else begin                                                  
         d0_rxlpn_dly <= {d0_rxlpn_dly[14:0],d0_rxlpn};    
         d0_rxlpp_dly <= {d0_rxlpp_dly[14:0],d0_rxlpp}; 
         if (d0_rxlpn_dly[2:1] == 0 && d0_rxlpp_dly[2:1] == 0)
            hs_term_en <= 1;
         else if (d0_rxlpn_dly[15:0] == 16'hffff && d0_rxlpp_dly[15:0] == 16'hffff)
            hs_term_en <= 0;
         if (d0_rxlpn_dly[11:3] == 0 && d0_rxlpp_dly[11:3] == 0)
            hs_des_en_tmp <= 1;
         else if (d0_rxlpn_dly[8:0] == 9'h1ff && d0_rxlpp_dly[8:0] == 9'h1ff)
            hs_des_en_tmp <= 0;        
         if (d0_rxlpn_dly[3:0] == 12) 
            data_lp_rx_en <= 0;  
         else if (d0_rxlpn_dly[2:0] == 3'h7 && d0_rxlpp_dly[2:0] == 3'h7) 
            data_lp_rx_en <= 1;                      
      end 
   end   
   
   always @(posedge rx_byte_clk or negedge rstn) begin                            
      if (rstn == 1'b0) begin                         
         hs_des_en_tmp_dly <= 0;     
      end 
      else begin                                                  
         hs_des_en_tmp_dly <= hs_des_en_tmp;       
      end 
   end   
   
   assign hs_des_en = hs_des_en_tmp | hs_des_en_tmp_dly;
   
   always @(negedge rx_byte_clk or negedge rstn) begin                            
      if (rstn == 1'b0) begin                         
         d_sot_det <= 0;   
         din_align_0 <= 0;
         din_align_1 <= 0;
         din_align_2 <= 0;
         din_align_3 <= 0;
      end 
      else begin                                                  
         d_sot_det <= d_sot_det_0[0];    
         din_align_0 <= din_comb[15:0]; 
         din_align_1 <= din_comb[31:16];
         din_align_2 <= din_comb[47:32];
         din_align_3 <= din_comb[63:48];
      end 
   end   
   
   always @(posedge rx_byte_clk or negedge hs_des_en) begin                            
      if (hs_des_en == 1'b0) begin 
         sync_out <= 0; 
         din_align_dly <= 0; 
         byte_data_out <= 0;
      end 
      else begin
         sync_out <= d_sot_det;   
         din_align_dly <= {din_align_3,din_align_2,din_align_1,din_align_0};         
         if (d_sot_det) 
            byte_data_out <= ~sync_out ? 64'hb800b800b800b800 : din_align_dly;  
      end 
   end      

endmodule 