`timescale 1ns/100ps 

module csi_raw12_4lane_gen_64b #(
   parameter IDLE_WAIT_TIME   = 16'd1000,     //16'd3553,      //power on wait time (number of byte clocks)
   parameter FRAME_WIDTH      = 12'd1920,     //12'd1920,      //number of active pixes(10bit) on each line                
   parameter FRAME_HEIGHT     = 12'd1080,     //12'd1080,      //number of active lines              
   parameter TOTAL_WIDTH      = 12'd2400,     //12'd2200,      //number of total pixels(10bit) on each line         
   parameter TOTAL_PIXELS     = 24'd2700000,  //24'd2475000,   //number of total pixels(10bit) in a frame
   parameter INTERV_SOF_DATA  = 12'd150,      //10'd50,        //time wait between SOF and the first data line (number of byte clocks)
   parameter INTERV_DATA_EOF  = 12'd150)      //10'd50 )       //time wait between the last data line and EOF (number of byte clocks)       
(
   input  wire        clk,
   input  wire        rstn, 
   output reg  [1:0]  lp_clk,             
   output reg         hs_clk_en,          
   output reg         hsxx_clk_en,        
   output reg  [1:0]  lp_data,                  
   output reg         hs_data_en, 
   output wire [63:0] data_out
);                    

   localparam T_LPX_LP01           = 5'd8;
   localparam T_HS_PREPARE_LP00    = 5'd8; 
   localparam T_HS_ZERO_HS00       = 5'd20;
   localparam T_HS_TRAIL           = 5'd10;
   
   localparam FRAME_WIDTH_BYTE_CLK = FRAME_WIDTH * 12/64;   
   localparam TOTAL_WIDTH_BYTE_CLK = TOTAL_WIDTH * 12/64;  
   localparam TOTAL_PIXELS_BYTE_CLK= TOTAL_PIXELS * 12/64;   
   localparam INTERV_DATA_DATA     = TOTAL_WIDTH_BYTE_CLK - FRAME_WIDTH_BYTE_CLK - T_LPX_LP01 - T_HS_PREPARE_LP00 - T_HS_ZERO_HS00 - T_HS_TRAIL - 2; 
   localparam HS_SOT_CLK_NUM       = 2;
   
   localparam FRAME_WIDTH_X2 = FRAME_WIDTH_BYTE_CLK * 8;
   
   localparam  CSI_TX_IDLE          = 3'h0;  
   localparam  CSI_TX_SOF           = 3'h1;
   localparam  CSI_TX_DATA_ST_WAIT  = 3'h2;
   localparam  CSI_TX_DATA          = 3'h3;
   localparam  CSI_TX_DATA_BLANK    = 3'h4; 
   localparam  CSI_TX_DATA_END_WAIT = 3'h5;
   localparam  CSI_TX_EOF           = 3'h6;  
   localparam  CSI_TX_FRAME_BLANK   = 3'h7;   
   
   localparam  CSI_TX_LP            = 3'h0;   
   localparam  CSI_TX_LPX           = 3'h1;   
   localparam  CSI_TX_HS_PREPARE    = 3'h2;   
   localparam  CSI_TX_HS_ZERO       = 3'h3;   
   localparam  CSI_TX_HS_SOT        = 3'h4;   
   localparam  CSI_TX_HS_DATA       = 3'h5;   
   localparam  CSI_TX_HS_TRAIL      = 3'h6;   
                                                        
   reg         poweron_rdy;                  //start sending CSI frames
   reg  [15:0] poweron_tmr; 
   
   reg  [2:0]  csi_tx_sm;
   reg         csi_tx_data_st_wait_done;     
   reg         line_cnt_done;                
   reg         csi_tx_data_blank_done;       
   reg         csi_tx_data_end_wait_done;    
   reg         csi_tx_frame_blank_done;      
   reg  [11:0] csi_tx_sm_cnt;
   reg  [11:0] line_cnt; 
   reg  [23:0] pix_cnt;
          
   reg  [2:0]  csi_tx_hs_sm;
   reg  [12:0] csi_tx_hs_sm_cnt;
   reg         csi_tx_lpx_done; 
   reg         csi_tx_hs_prepare_done;
   reg         csi_tx_hs_zero_done;
   reg         csi_tx_hs_sot_done;
   reg         csi_tx_hs_data_done;
   reg         csi_tx_hs_trail_done;     
   
   wire [15:0] wc; 
   
   reg  [11:0] pix_data0;
   reg  [11:0] pix_data1;
   reg  [11:0] pix_data2;
   reg  [11:0] pix_data3; 
   reg  [11:0] pix_data4; 
   reg  [11:0] pix_data5; 
   reg  [11:0] pix_data6; 
   reg  [11:0] pix_data7; 
   reg  [11:0] pix_data8;
   reg  [11:0] pix_data9;
   reg  [11:0] pix_data10;
   reg  [11:0] pix_data11; 
   reg  [11:0] pix_data12; 
   reg  [11:0] pix_data13; 
   reg  [11:0] pix_data14; 
   reg  [11:0] pix_data15; 
   reg  [2:0]  data_sel_cnt;
   reg  [15:0] frame_num;
   reg  [63:0] crc_din;
   wire [15:0] crc_out;
   reg  [23:0] ecc_din;
   wire [7:0]  ecc_out; 
   wire        crc_init;
   reg         crc_din_en;
   
   reg  [15:0] csi_byte_d3;    
   reg  [15:0] csi_byte_d2;    
   reg  [15:0] csi_byte_d1;
   reg  [15:0] csi_byte_d0;    
   
   assign wc = FRAME_WIDTH_X2;
   
// timer for IDLE_WAIT_TIME*cycles after power on
   always @(posedge clk or negedge rstn) begin
      if (!rstn) begin 
         poweron_tmr <= 0;
         poweron_rdy <= 0;
      end
      else begin
         if (poweron_tmr != IDLE_WAIT_TIME) 
            poweron_tmr <= poweron_tmr + 1;
         else
            poweron_rdy <= 1;   
      end
   end
   
   always @(posedge clk or negedge rstn) begin             
      if (!rstn) begin                    
         csi_tx_sm <= CSI_TX_IDLE;   
      end  
      else begin
         case (csi_tx_sm)
            CSI_TX_IDLE : begin 
               if (poweron_rdy)                
                  csi_tx_sm <= CSI_TX_SOF;       
            end
            CSI_TX_SOF : begin  
               if (csi_tx_hs_trail_done) 
                  csi_tx_sm <= CSI_TX_DATA_ST_WAIT;
            end 
            CSI_TX_DATA_ST_WAIT : begin    
               if (csi_tx_data_st_wait_done) 
                  csi_tx_sm <= CSI_TX_DATA;  
            end                                       
            CSI_TX_DATA : begin 
               if (csi_tx_hs_trail_done) begin
                  if (line_cnt_done)
                     csi_tx_sm <= CSI_TX_DATA_END_WAIT; 
                  else
                     csi_tx_sm <= CSI_TX_DATA_BLANK;   
               end
            end
            CSI_TX_DATA_BLANK : begin  
               if (csi_tx_data_blank_done)
                  csi_tx_sm <= CSI_TX_DATA;   
            end 
            CSI_TX_DATA_END_WAIT : begin  
               if (csi_tx_data_end_wait_done) 
                  csi_tx_sm <= CSI_TX_EOF;      
            end 
            CSI_TX_EOF : begin  
               if (csi_tx_hs_trail_done) 
                  csi_tx_sm <= CSI_TX_FRAME_BLANK;
            end 
            CSI_TX_FRAME_BLANK : begin  
               if (csi_tx_frame_blank_done) 
                  csi_tx_sm <= CSI_TX_SOF;
            end 
         endcase
      end
   end
   
   always @ (posedge clk or negedge rstn) begin
      if (!rstn) begin  
         csi_tx_sm_cnt <= 0;
         line_cnt <= 0;
         csi_tx_data_st_wait_done <= 0;
         csi_tx_data_end_wait_done <= 0;     
         csi_tx_data_blank_done <= 0;         
         line_cnt_done <= 0;
         pix_cnt <= 0; 
         csi_tx_frame_blank_done <= 0;
      end
      else begin
         if (csi_tx_sm == CSI_TX_DATA_ST_WAIT || csi_tx_sm == CSI_TX_DATA_BLANK || csi_tx_sm == CSI_TX_DATA_END_WAIT) 
            csi_tx_sm_cnt <= csi_tx_sm_cnt + 1; 
         else 
            csi_tx_sm_cnt <= 0;    
         csi_tx_data_st_wait_done <= (csi_tx_sm_cnt == INTERV_SOF_DATA - 3) && csi_tx_sm == CSI_TX_DATA_ST_WAIT;
         csi_tx_data_end_wait_done <= (csi_tx_sm_cnt == INTERV_DATA_EOF - 3) && csi_tx_sm == CSI_TX_DATA_END_WAIT;    
         csi_tx_data_blank_done <= (csi_tx_sm_cnt == INTERV_DATA_DATA - 3) && csi_tx_sm == CSI_TX_DATA_BLANK;        
         if (csi_tx_sm == CSI_TX_SOF || csi_tx_sm == CSI_TX_EOF)
            line_cnt <= 0; 
         else if ((csi_tx_sm == CSI_TX_DATA_ST_WAIT && csi_tx_data_st_wait_done) || (csi_tx_sm == CSI_TX_DATA_BLANK && csi_tx_data_blank_done)) 
            line_cnt <= line_cnt + 1;
         line_cnt_done <= line_cnt == FRAME_HEIGHT; 
         if (csi_tx_sm == CSI_TX_IDLE || csi_tx_frame_blank_done)
            pix_cnt <= 0; 
         else
            pix_cnt <= pix_cnt + 1; 
         csi_tx_frame_blank_done <= pix_cnt == TOTAL_PIXELS_BYTE_CLK - 2;               
      end
   end
   
   always @(posedge clk or negedge rstn) begin             
      if (!rstn) begin                    
         csi_tx_hs_sm <= CSI_TX_LP;   
      end  
      else begin
         case (csi_tx_hs_sm)
            CSI_TX_LP : begin 
               if (csi_tx_sm == CSI_TX_SOF || csi_tx_sm == CSI_TX_EOF || csi_tx_sm == CSI_TX_DATA)                
                  csi_tx_hs_sm <= CSI_TX_LPX;       
            end
            CSI_TX_LPX : begin  
               if (csi_tx_lpx_done) 
                  csi_tx_hs_sm <= CSI_TX_HS_PREPARE;
            end 
            CSI_TX_HS_PREPARE : begin    
               if (csi_tx_hs_prepare_done) 
                  csi_tx_hs_sm <= CSI_TX_HS_ZERO;  
            end  
            CSI_TX_HS_ZERO : begin    
               if (csi_tx_hs_zero_done) 
                  csi_tx_hs_sm <= CSI_TX_HS_SOT; 
            end                                       
            CSI_TX_HS_SOT : begin 
               if (csi_tx_hs_sot_done) begin  
                  if (csi_tx_sm == CSI_TX_DATA)
                     csi_tx_hs_sm <= CSI_TX_HS_DATA;
                  else  
                     csi_tx_hs_sm <= CSI_TX_HS_TRAIL;  
               end 
            end
            CSI_TX_HS_DATA : begin  
               if (csi_tx_hs_data_done)
                  csi_tx_hs_sm <= CSI_TX_HS_TRAIL;   
            end 
            CSI_TX_HS_TRAIL : begin  
               if (csi_tx_hs_trail_done) 
                  csi_tx_hs_sm <= CSI_TX_LP;      
            end 
         endcase
      end
   end
   
   always @ (posedge clk or negedge rstn) begin
      if (!rstn) begin  
         csi_tx_hs_sm_cnt <= 0;
         csi_tx_lpx_done <= 0;
         csi_tx_hs_prepare_done <= 0;     
         csi_tx_hs_zero_done <= 0;         
         csi_tx_hs_sot_done <= 0;
         csi_tx_hs_data_done <= 0; 
         csi_tx_hs_trail_done <= 0;
         lp_clk <= 3;         
         hs_clk_en <= 0;      
         hsxx_clk_en <= 0;    
      end
      else begin
         if (csi_tx_hs_sm == CSI_TX_LP || csi_tx_lpx_done || csi_tx_hs_prepare_done || csi_tx_hs_zero_done || csi_tx_hs_sot_done || csi_tx_hs_data_done || csi_tx_hs_trail_done) 
            csi_tx_hs_sm_cnt <= 0;   
         else 
            csi_tx_hs_sm_cnt <= csi_tx_hs_sm_cnt + 1;     
         csi_tx_lpx_done <= (csi_tx_hs_sm_cnt == T_LPX_LP01 - 2) && (csi_tx_hs_sm == CSI_TX_LPX);
         csi_tx_hs_prepare_done <= (csi_tx_hs_sm_cnt == T_HS_PREPARE_LP00 - 2) && (csi_tx_hs_sm == CSI_TX_HS_PREPARE);                                   
         csi_tx_hs_zero_done <= (csi_tx_hs_sm_cnt == T_HS_ZERO_HS00 - 2) && (csi_tx_hs_sm == CSI_TX_HS_ZERO);                                            
         csi_tx_hs_sot_done <= /*(csi_tx_hs_sm_cnt == HS_SOT_CLK_NUM - 2) && (csi_tx_hs_sm == CSI_TX_HS_SOT)*/csi_tx_hs_zero_done;                                              
         csi_tx_hs_data_done <= (csi_tx_hs_sm_cnt == FRAME_WIDTH_BYTE_CLK - 1) && (csi_tx_hs_sm == CSI_TX_HS_DATA);                                       
         csi_tx_hs_trail_done <= (csi_tx_hs_sm_cnt == T_HS_TRAIL - 2) && (csi_tx_hs_sm == CSI_TX_HS_TRAIL);      
         if (poweron_tmr == IDLE_WAIT_TIME - 200 || pix_cnt == TOTAL_PIXELS_BYTE_CLK - 200)// || (csi_tx_sm_cnt == INTERV_SOF_DATA - 53 && csi_tx_sm == CSI_TX_DATA_ST_WAIT) || (csi_tx_sm_cnt == INTERV_DATA_DATA - 53 && csi_tx_sm == CSI_TX_DATA_BLANK) || (csi_tx_sm_cnt == INTERV_DATA_EOF - 53 && csi_tx_sm == CSI_TX_DATA_END_WAIT))
            lp_clk <= 1;
         else if (poweron_tmr == IDLE_WAIT_TIME - 192 || pix_cnt == TOTAL_PIXELS_BYTE_CLK - 192)// || (csi_tx_sm_cnt == INTERV_SOF_DATA - 45 && csi_tx_sm == CSI_TX_DATA_ST_WAIT) || (csi_tx_sm_cnt == INTERV_DATA_DATA - 45 && csi_tx_sm == CSI_TX_DATA_BLANK) || (csi_tx_sm_cnt == INTERV_DATA_EOF - 45 && csi_tx_sm == CSI_TX_DATA_END_WAIT))       
            lp_clk <= 0;
         else if (pix_cnt == TOTAL_PIXELS_BYTE_CLK - 2000)
            lp_clk <= 3;     
         if (poweron_tmr == IDLE_WAIT_TIME - 182 || pix_cnt == TOTAL_PIXELS_BYTE_CLK - 182)// || (csi_tx_sm_cnt == INTERV_SOF_DATA - 37 && csi_tx_sm == CSI_TX_DATA_ST_WAIT) || (csi_tx_sm_cnt == INTERV_DATA_DATA - 37 && csi_tx_sm == CSI_TX_DATA_BLANK) || (csi_tx_sm_cnt == INTERV_DATA_EOF - 37 && csi_tx_sm == CSI_TX_DATA_END_WAIT)) 
            hs_clk_en <= 1;
         else if (pix_cnt == TOTAL_PIXELS_BYTE_CLK - 2000)
            hs_clk_en <= 0;     
         if (poweron_tmr == IDLE_WAIT_TIME - 152 || pix_cnt == TOTAL_PIXELS_BYTE_CLK - 152)// || (csi_tx_sm_cnt == INTERV_SOF_DATA - 21 && csi_tx_sm == CSI_TX_DATA_ST_WAIT) || (csi_tx_sm_cnt == INTERV_DATA_DATA - 21 && csi_tx_sm == CSI_TX_DATA_BLANK) || (csi_tx_sm_cnt == INTERV_DATA_EOF - 21 && csi_tx_sm == CSI_TX_DATA_END_WAIT)) 
            hsxx_clk_en <= 1;   
         else if (pix_cnt == TOTAL_PIXELS_BYTE_CLK - 2000)
            hsxx_clk_en <= 0;                                                
      end
   end
   
   always @ (posedge clk or negedge rstn) begin
      if (!rstn) begin
         pix_data0  <= 12'h0;
         pix_data1  <= 12'h1;
         pix_data2  <= 12'h2;
         pix_data3  <= 12'h3;    
         pix_data4  <= 12'h4;    
         pix_data5  <= 12'h5;    
         pix_data6  <= 12'h6;    
         pix_data7  <= 12'h7; 
         pix_data8  <= 12'h8 ;       
         pix_data9  <= 12'h9 ;       
         pix_data10 <= 12'h10;       
         pix_data11 <= 12'h11;       
         pix_data12 <= 12'h12;       
         pix_data13 <= 12'h13;       
         pix_data14 <= 12'h14;       
         pix_data15 <= 12'h15;          
         data_sel_cnt <= 0;
         frame_num <= 16'h0;
         crc_din <= 64'h0;  
         ecc_din <= 24'h0;  
         crc_din_en <= 0;
      end
      else begin
         if (csi_tx_hs_sm == CSI_TX_HS_DATA) begin
            if (data_sel_cnt == 2) 
               data_sel_cnt <= 0;
            else
               data_sel_cnt <= data_sel_cnt + 1;
         end
         else 
            data_sel_cnt <= 0;
         if (csi_tx_hs_sm == CSI_TX_HS_DATA) begin
            if (data_sel_cnt == 1) begin
               pix_data0  <= pix_data0 + 16;
               pix_data1  <= pix_data1 + 16;
               pix_data2  <= pix_data2 + 16;
               pix_data3  <= pix_data3 + 16;     
               pix_data4  <= pix_data4 + 16;     
               pix_data5  <= pix_data5 + 16;     
               pix_data6  <= pix_data6 + 16;     
               pix_data7  <= pix_data7 + 16;  
               pix_data8  <= pix_data8 + 16;                 
               pix_data9  <= pix_data9 + 16;                 
               pix_data10 <= pix_data10+ 16;                 
               pix_data11 <= pix_data11+ 16;                 
               pix_data12 <= pix_data12+ 16;                 
               pix_data13 <= pix_data13+ 16;                 
               pix_data14 <= pix_data14+ 16;                 
               pix_data15 <= pix_data15+ 16;                 
            end
         end
         else begin
            pix_data0 <= 12'h0;
            pix_data1 <= 12'h1;
            pix_data2 <= 12'h2;
            pix_data3 <= 12'h3;     
            pix_data4 <= 12'h4;    
            pix_data5 <= 12'h5;    
            pix_data6 <= 12'h6;    
            pix_data7 <= 12'h7;  
            pix_data8  <= 12'h8 ;          
            pix_data9  <= 12'h9 ;          
            pix_data10 <= 12'h10;          
            pix_data11 <= 12'h11;          
            pix_data12 <= 12'h12;          
            pix_data13 <= 12'h13;          
            pix_data14 <= 12'h14;          
            pix_data15 <= 12'h15;            
         end
         
         if (csi_tx_hs_sot_done)
            crc_din <= {pix_data5[11:4],pix_data4[11:4],pix_data3[3:0],pix_data2[3:0],pix_data3[11:4],pix_data2[11:4],pix_data1[3:0],pix_data0[3:0],pix_data1[11:4],pix_data0[11:4]};
         else begin
            case (data_sel_cnt)
               3'h0 : crc_din <= {pix_data10[11:4],pix_data9[3:0],pix_data8[3:0],pix_data9[11:4],pix_data8[11:4],pix_data7[3:0],pix_data6[3:0],pix_data7[11:4],pix_data6[11:4],pix_data5[3:0],pix_data4[3:0]};
               3'h1 : crc_din <= {pix_data15[3:0],pix_data14[3:0],pix_data15[11:4],pix_data14[11:4],pix_data13[3:0],pix_data12[3:0],pix_data13[11:4],pix_data12[11:4],pix_data11[3:0],pix_data10[3:0],pix_data11[11:4]};
               3'h2 : crc_din <= {pix_data5[11:4],pix_data4[11:4],pix_data3[3:0],pix_data2[3:0],pix_data3[11:4],pix_data2[11:4],pix_data1[3:0],pix_data0[3:0],pix_data1[11:4],pix_data0[11:4]}; 
            endcase 
         end
         
         if (csi_tx_hs_sot_done && csi_tx_sm == CSI_TX_DATA)
            crc_din_en <= 1; 
         else if (csi_tx_hs_data_done) 
            crc_din_en <= 0;      
         
         if (csi_tx_frame_blank_done)
            frame_num <= frame_num + 1;
         if (csi_tx_sm == CSI_TX_SOF)
            ecc_din <= {frame_num,8'h00}; 
         else if (csi_tx_sm == CSI_TX_EOF)
            ecc_din <= {frame_num,8'h01};  
         else if (csi_tx_sm == CSI_TX_DATA)   
            ecc_din <= {wc,8'h2c};       
      end
   end
   
   assign crc_init = csi_tx_hs_sot_done;
   
   crc16_64b crc16_64b_inst (                           
      .clk      (clk           ),                       
      .rstn     (rstn          ),              
      .init     (crc_init      ),             
      .din      (crc_din       ),             
      .din_en   (crc_din_en    ),             
      .crc      (crc_out       )
   );
   
   ecc_gen ecc_gen_inst (
      .clk      (clk           ),        
      .rstn     (rstn          ),        
      .din      (ecc_din       ),
      .ecc_out  (ecc_out       )
   );
   
   always @(posedge clk or negedge rstn) begin                                                           
      if (!rstn) begin
         csi_byte_d0 <= 8'h00;
         csi_byte_d1 <= 8'h00; 
         csi_byte_d2 <= 8'h00; 
         csi_byte_d3 <= 8'h00; 
      end                                                                                                  
      else begin
         case (csi_tx_hs_sm)
            CSI_TX_LP         : begin csi_byte_d3 <= 0;  csi_byte_d2 <= 0; csi_byte_d1 <= 0;  csi_byte_d0 <= 0; end  
            CSI_TX_LPX        : begin csi_byte_d3 <= 0;  csi_byte_d2 <= 0; csi_byte_d1 <= 0;  csi_byte_d0 <= 0; end 
            CSI_TX_HS_PREPARE : begin csi_byte_d3 <= 0;  csi_byte_d2 <= 0; csi_byte_d1 <= 0;  csi_byte_d0 <= 0; end 
            CSI_TX_HS_ZERO    : begin csi_byte_d3 <= 0;  csi_byte_d2 <= 0; csi_byte_d1 <= 0;  csi_byte_d0 <= 0; end 
            CSI_TX_HS_SOT     : begin csi_byte_d3 <= {ecc_out,8'hb8}; csi_byte_d2 <= {ecc_din[23:16],8'hb8}; csi_byte_d1 <= {ecc_din[15:8],8'hb8}; csi_byte_d0 <= {ecc_din[7:0],8'hb8}; end
            CSI_TX_HS_DATA    : begin 
               if (csi_tx_hs_data_done) begin
                  csi_byte_d3 <= 16'hffff;           csi_byte_d2 <= 16'hffff;          csi_byte_d1 <= {8'hff,crc_out[15:8]};  csi_byte_d0 <= {8'hff,crc_out[7:0]}; 
               end
               else begin
                  csi_byte_d3 <= {crc_din[63:56],crc_din[31:24]};  csi_byte_d2 <= {crc_din[55:48],crc_din[23:16]}; csi_byte_d1 <= {crc_din[47:40],crc_din[15:8]};  csi_byte_d0 <= {crc_din[39:32],crc_din[7:0]}; 
               end
            end  
            CSI_TX_HS_TRAIL   : begin csi_byte_d3 <= 16'hffff; csi_byte_d2 <= 16'hffff; csi_byte_d1 <= 16'hffff;  csi_byte_d0 <= 16'hffff; end  
         endcase
      end
   end 
   
   assign data_out = {csi_byte_d3,csi_byte_d2,csi_byte_d1,csi_byte_d0};
   
   always @(posedge clk or negedge rstn) begin
      if(!rstn) begin 
         lp_data <= 3;
         hs_data_en <=  0;
      end
      else begin 
         case (csi_tx_hs_sm)
            CSI_TX_LP         : begin lp_data <= 3;  hs_data_en <= 0; end 
            CSI_TX_LPX        : begin lp_data <= 1;  hs_data_en <= 0; end  
            CSI_TX_HS_PREPARE : begin lp_data <= 0;  hs_data_en <= 0; end  
            CSI_TX_HS_ZERO    : begin lp_data <= 0;  hs_data_en <= 1; end  
            CSI_TX_HS_SOT     : begin lp_data <= 0;  hs_data_en <= 1; end  
            CSI_TX_HS_DATA    : begin lp_data <= 0;  hs_data_en <= 1; end  
            CSI_TX_HS_TRAIL   : begin lp_data <= 0;  hs_data_en <= 1; end  
         endcase
      end
   end

endmodule 

