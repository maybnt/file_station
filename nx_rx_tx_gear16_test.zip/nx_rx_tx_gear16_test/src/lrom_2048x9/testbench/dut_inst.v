    lrom_2048x9 u_lrom_2048x9(.clk_i(clk_i),
        .dps_i(dps_i),
        .rst_i(rst_i),
        .clk_en_i(clk_en_i),
        .addr_i(addr_i),
        .rd_data_o(rd_data_o),
        .lramready_o(lramready_o),
        .rd_datavalid_o(rd_datavalid_o));
