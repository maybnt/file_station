`timescale 1 ns / 1 ns

`include "lram_mem_model.v"
`include "lscc_rstclk_gen.v"
`include "lram_mem_master.v"

`ifndef _TB_TOP_
`define _TB_TOP_

module tb_top();

`include "dut_params.v"

localparam CLK_PERIOD = 100;
localparam RST_DELAY  = 35;
localparam RST_SYNC   = "sync";
localparam TIMEOUT    = 100000000;

// ----------------------
// ----- IP signals -----
// ----------------------
wire clk_i;
wire dps_i;
wire rst_i;

wire errdet_o;
wire lramready_o;

wire                  clk_en_i;
wire                  rdout_clken_i;
wire [ADDR_WIDTH-1:0] addr_i;
wire [3:0]            ualigned_i;

wire [DATA_WIDTH-1:0] rd_data_o;
wire                  rd_datavalid_o;
wire [1:0]            ecc_errdet_o;

`include "dut_inst.v"

GSR GSR_INST( .GSR_N(1'b1), .CLK(1'b0));

generate
    localparam T_BEN_W = ((DATA_WIDTH/8) < 1) ? 1 : DATA_WIDTH/8;
    wire [T_BEN_W-1:0] bent;
    wire [DATA_WIDTH-1:0] mem_rd_data_a_o;
    wire [DATA_WIDTH-1:0] mem_rd_data_b_o;
    wire rst_w;
    assign rst_i = rst_w;
    assign bent = {T_BEN_W{1'b1}};
    
    lscc_rstclk_gen # (
        .CLK_PERIOD (CLK_PERIOD),
        .RST_DELAY  (RST_DELAY ),
        .RST_SYNC   (RST_SYNC  ),
        .TIMEOUT    (TIMEOUT   )
    ) clk_rst_gen (
        .clk_o   (clk_i),
        .rst_o   (rst_w),
        .rst_n_o ()
    );
    
    lram_mem_master # (
        .MEM_TYPE         ("lram_rom"      ),
        .ADDR_DEPTH_A     (ADDR_DEPTH      ),
        .DATA_WIDTH_A     (DATA_WIDTH      ),
        .ADDR_DEPTH_B     (ADDR_DEPTH      ),
        .DATA_WIDTH_B     (DATA_WIDTH      ),
        .REGMODE_A        (REGMODE         ),
        .REGMODE_B        (REGMODE         ),
        .RESETMODE        (RESETMODE       ),
        .RESET_RELEASE    (RESET_RELEASE   ),
        .BYTE_ENABLE_A    (0               ),
        .BYTE_ENABLE_B    (0               ),
        .WRITE_MODE_A     ("normal"        ),
        .WRITE_MODE_B     ("normal"        ),
        .UNALIGNED_READ   (UNALIGNED_READ  ),
        .INIT_MODE        (INIT_MODE       ),
        .INIT_FILE        (INIT_FILE       ),
        .INIT_FILE_FORMAT (INIT_FILE_FORMAT),
        .BYTE_WIDTH_A     (T_BEN_W         ),
        .BYTE_WIDTH_B     (T_BEN_W         )
    ) mem_master (
    // --------------------------
    // ----- Common Signals -----
    // --------------------------
        .clk_i           (clk_i),
        .dps_i           (dps_i),
    // --------------------------
    // ----- Port A signals -----
    // --------------------------
        .rst_a_i         (rst_i),
        .clk_en_a_i      (clk_en_i),
        .rdout_clken_a_i (rdout_clken_i),
        .wr_en_a_i       (),
        .wr_data_a_i     (),
        .addr_a_i        (addr_i),
        .ben_a_i         (ualigned_i), 
    
        .rd_data_a_o     (rd_data_o),
        .mem_data_a_o    (mem_rd_data_a_o),
    // --------------------------
    // ----- Port B signals -----
    // --------------------------
        .rst_b_i         (rst_i),
        .clk_en_b_i      (),
        .rdout_clken_b_i (),
        .wr_en_b_i       (),
        .wr_data_b_i     (),
        .addr_b_i        (),
        .ben_b_i         (), 
    
        .rd_data_b_o     (rd_data_b_o),
        .mem_data_b_o    (mem_rd_data_b_o)
    );
    
    lram_mem_model # (
        .ADDR_DEPTH_A     (ADDR_DEPTH      ),
        .DATA_WIDTH_A     (DATA_WIDTH      ),
        .ADDR_DEPTH_B     (ADDR_DEPTH      ),
        .DATA_WIDTH_B     (DATA_WIDTH      ),
        .REGMODE_A        (REGMODE         ),
        .REGMODE_B        (REGMODE         ),
        .RESETMODE        (RESETMODE       ),
        .RESET_RELEASE    (RESET_RELEASE   ),
        .BYTE_ENABLE_A    (0               ),
        .BYTE_ENABLE_B    (0               ),
        .WRITE_MODE_A     ("normal"        ),
        .WRITE_MODE_B     ("normal"        ),
        .UNALIGNED_READ   (UNALIGNED_READ  ),
        .INIT_MODE        (INIT_MODE       ),
        .INIT_FILE        (INIT_FILE       ),
        .INIT_FILE_FORMAT (INIT_FILE_FORMAT)
    ) mem_model (
    // --------------------------
    // ----- Common Signals -----
    // --------------------------
        .clk_i           (clk_i),
    // --------------------------
    // ----- Port A signals -----
    // --------------------------
        .rst_a_i         (rst_i),
        .clk_en_a_i      (clk_en_i),
        .rdout_clken_a_i (rdout_clken_i),
        .wr_en_a_i       (1'b0),
        .wr_data_a_i     ({DATA_WIDTH{1'b0}}),
        .addr_a_i        (addr_i),
        .ben_a_i         (ben_i), 
    
        .rd_data_a_o     (mem_rd_data_a_o),
    // --------------------------
    // ----- Port B signals -----
    // --------------------------
        .rst_b_i         (rst_i),
        .clk_en_b_i      (clk_en_i),
        .rdout_clken_b_i (1'b1),
        .wr_en_b_i       (1'b0),
        .wr_data_b_i     ({DATA_WIDTH{1'b0}}),
        .addr_b_i        (addr_i),
        .ben_b_i         (bent), 
    
        .rd_data_b_o     (mem_rd_data_b_o)
    );
endgenerate

endmodule
`endif
