    lrom_2048x9 __(.clk_i( ),
        .dps_i( ),
        .rst_i( ),
        .clk_en_i( ),
        .addr_i( ),
        .rd_data_o( ),
        .lramready_o( ),
        .rd_datavalid_o( ));
