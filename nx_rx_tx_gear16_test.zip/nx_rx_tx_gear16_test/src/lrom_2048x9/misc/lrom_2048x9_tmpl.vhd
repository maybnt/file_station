component lrom_2048x9 is
    port(
        clk_i: in std_logic;
        dps_i: in std_logic;
        rst_i: in std_logic;
        clk_en_i: in std_logic;
        addr_i: in std_logic_vector(10 downto 0);
        rd_data_o: out std_logic_vector(8 downto 0);
        lramready_o: out std_logic;
        rd_datavalid_o: out std_logic
    );
end component;

__: lrom_2048x9 port map(
    clk_i=>,
    dps_i=>,
    rst_i=>,
    clk_en_i=>,
    addr_i=>,
    rd_data_o=>,
    lramready_o=>,
    rd_datavalid_o=>
);
